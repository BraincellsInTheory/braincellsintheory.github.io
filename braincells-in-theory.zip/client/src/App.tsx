import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";

// Pages
import Home from "./pages/Home";
import Subjects from "./pages/Subjects";
import SubjectHub from "./pages/SubjectHub";
import StudyGuide from "./pages/StudyGuide";
import PanicMode from "./pages/PanicMode";
import Flashcards from "./pages/Flashcards";
import Planner from "./pages/Planner";
import QuizGenerator from "./pages/QuizGenerator";
import Blog from "./pages/Blog";
import About from "./pages/About";
import Community from "./pages/Community";
import Contact from "./pages/Contact";
import Team from "./pages/Team";
import Developer from "./pages/Developer";
import StudyTools from "./pages/StudyTools";
import ResourceLibrary from "./pages/ResourceLibrary";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/subjects" component={Subjects} />
      <Route path="/subjects/:subject" component={SubjectHub} />
      <Route path="/subjects/:subject/:topic" component={SubjectHub} />
      <Route path="/guides/:slug" component={StudyGuide} />
      <Route path="/panic" component={PanicMode} />
      <Route path="/flashcards" component={Flashcards} />
      <Route path="/planner" component={Planner} />
      <Route path="/quiz" component={QuizGenerator} />
      <Route path="/tools" component={StudyTools} />
      <Route path="/blog" component={Blog} />
      <Route path="/blog/:slug" component={Blog} />
      <Route path="/resources" component={ResourceLibrary} />
      <Route path="/community" component={Community} />
      <Route path="/about" component={About} />
      <Route path="/team" component={Team} />
      <Route path="/contact" component={Contact} />
      <Route path="/developer" component={Developer} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
