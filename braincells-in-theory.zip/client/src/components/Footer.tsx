/* BiT Footer — Chaotic Textbook Riot design */
import { Link } from "wouter";
import { toast } from "sonner";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663765059109/J3DCNwY54D46DrPmWoXEao/bit-logo-4W3dQ5wmYvnqeJknNAGtoL.png";

const footerLinks = {
  Study: [
    { label: "Subjects", href: "/subjects" },
    { label: "Flashcards", href: "/flashcards" },
    { label: "Study Guides", href: "/subjects/math/algebra" },
    { label: "Quiz Generator", href: "/quiz" },
    { label: "Resource Library", href: "/resources" },
  ],
  Tools: [
    { label: "Planner", href: "/planner" },
    { label: "Panic Mode", href: "/panic" },
    { label: "Study Tools Overview", href: "/tools" },
    { label: "Formula Vault", href: "/resources#formulas" },
    { label: "Pomodoro Timer", href: "/planner#pomodoro" },
  ],
  Community: [
    { label: "Community Hub", href: "/community" },
    { label: "Blog & Articles", href: "/blog" },
    { label: "Events", href: "/community#events" },
    { label: "Leaderboard", href: "/community#leaderboard" },
    { label: "Mentorship", href: "/community#mentorship" },
  ],
  About: [
    { label: "About BiT", href: "/about" },
    { label: "Our Team", href: "/team" },
    { label: "Contact", href: "/contact" },
    { label: "Developer / API", href: "/developer" },
    { label: "Changelog", href: "/about#changelog" },
  ],
};

const sarcasmQuotes = [
  "You're still here? Go study.",
  "This footer won't help you pass.",
  "Scrolling to the bottom = procrastinating.",
  "Congratulations on finding the footer. Now open your textbook.",
  "The answer is not in the footer. It never was.",
];

export default function Footer() {
  const quote = sarcasmQuotes[Math.floor(Math.random() * sarcasmQuotes.length)];

  return (
    <footer className="bg-[#080808] border-t border-[#1A1A1A] pt-16 pb-8 relative overflow-hidden">
      {/* Decorative top border */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#FFD600]/30 to-transparent" />

      <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
        {/* Main grid */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 mb-12">
          {/* Brand column */}
          <div className="col-span-2 md:col-span-1">
            <Link href="/" className="flex items-center gap-2 mb-4 group">
              <img src={LOGO_URL} alt="BiT" className="w-8 h-8 object-contain" />
              <span className="font-display font-black text-xl text-[#FFD600]">BiT</span>
            </Link>
            <p className="font-body text-sm text-[#555] leading-relaxed mb-4">
              The study platform for students who know they're cooked but show up anyway.
            </p>
            <div className="flex gap-3">
              {["𝕏", "ig", "yt", "dc"].map((s) => (
                <button
                  key={s}
                  onClick={() => toast.info("Social links coming soon.")}
                  className="w-8 h-8 rounded bg-[#1A1A1A] border border-[#222] flex items-center justify-center font-mono text-xs text-[#555] hover:text-[#FFD600] hover:border-[#FFD600]/30 transition-all"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* Link columns */}
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h4 className="font-display font-700 text-xs uppercase tracking-widest text-[#FFD600] mb-4">
                {category}
              </h4>
              <ul className="space-y-2">
                {links.map((link) => (
                  <li key={`${category}-${link.label}`}>
                    <Link
                      href={link.href}
                      className="font-body text-sm text-[#555] hover:text-[#F5F0E8] transition-colors"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Sarcasm quote */}
        <div className="border border-[#1A1A1A] rounded p-4 mb-8 flex items-center gap-3">
          <span className="text-[#FFD600] text-lg shrink-0">💡</span>
          <p className="font-mono text-xs text-[#444] italic">"{quote}"</p>
        </div>

        {/* Bottom bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-6 border-t border-[#1A1A1A]">
          <p className="font-mono text-xs text-[#333]">
            © {new Date().getFullYear()} BRAINCELLS IN THEORY. All rights reserved.{" "}
            <span className="text-[#222]">(Not that we can stop you from copying notes.)</span>
          </p>
          <div className="flex items-center gap-4">
            <button
              onClick={() => toast.info("Privacy policy coming soon.")}
              className="font-mono text-xs text-[#333] hover:text-[#555] transition-colors"
            >
              Privacy
            </button>
            <button
              onClick={() => toast.info("Terms coming soon.")}
              className="font-mono text-xs text-[#333] hover:text-[#555] transition-colors"
            >
              Terms
            </button>
            <span className="font-mono text-xs text-[#222]">v1.0.0-beta</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
