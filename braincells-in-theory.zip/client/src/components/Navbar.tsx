/* ============================================================
   BiT Navbar — "Chaotic Textbook Riot" design
   Compresses on scroll, theme changes per section
   ============================================================ */
import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663765059109/J3DCNwY54D46DrPmWoXEao/bit-logo-4W3dQ5wmYvnqeJknNAGtoL.png";

const navLinks = [
  { label: "Subjects", href: "/subjects", sub: [
    { label: "Mathematics ∑", href: "/subjects/math" },
    { label: "Science ⚛", href: "/subjects/science" },
    { label: "History 🗺", href: "/subjects/history" },
    { label: "English ✍", href: "/subjects/english" },
  ]},
  { label: "Study Tools", href: "/tools", sub: [
    { label: "Flashcards", href: "/flashcards" },
    { label: "Quiz Generator", href: "/quiz" },
    { label: "Study Planner", href: "/planner" },
    { label: "🚨 Panic Mode", href: "/panic" },
  ]},
  { label: "Blog", href: "/blog" },
  { label: "Resources", href: "/resources" },
  { label: "Community", href: "/community" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const [location] = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
    setOpenDropdown(null);
  }, [location]);

  const handlePanic = () => {
    window.location.href = "/panic";
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "py-2 bg-[#0D0D0D]/95 backdrop-blur-xl border-b border-[#FFD600]/20 shadow-[0_2px_20px_rgba(255,214,0,0.1)]"
          : "py-4 bg-transparent"
      }`}
    >
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 flex items-center justify-between gap-4">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2.5 group shrink-0">
          <img
            src={LOGO_URL}
            alt="BiT Logo"
            className="w-8 h-8 object-contain transition-transform duration-300 group-hover:rotate-12"
          />
          <div className="flex flex-col leading-none">
            <span className="font-display font-black text-lg tracking-tight text-[#FFD600]">
              Bi<span className="text-white">T</span>
            </span>
            <span className="font-mono text-[9px] text-[#555] uppercase tracking-widest hidden sm:block">
              braincells in theory
            </span>
          </div>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-1">
          {navLinks.map((link) => (
            <div
              key={link.href}
              className="relative"
              onMouseEnter={() => link.sub && setOpenDropdown(link.label)}
              onMouseLeave={() => setOpenDropdown(null)}
            >
              <Link
                href={link.href}
                className={`font-display font-600 text-sm px-3 py-2 rounded transition-all duration-200 relative group ${
                  location === link.href
                    ? "text-[#FFD600]"
                    : "text-[#F5F0E8]/80 hover:text-[#FFD600]"
                }`}
              >
                {link.label}
                {link.sub && (
                  <span className="ml-1 text-[10px] opacity-50">▾</span>
                )}
                <span className="absolute bottom-0 left-3 right-3 h-px bg-[#FFD600] scale-x-0 group-hover:scale-x-100 transition-transform duration-200 origin-left" />
              </Link>
              {link.sub && openDropdown === link.label && (
                <div className="absolute top-full left-0 mt-1 w-48 bg-[#1A1A1A] border border-[#333] rounded shadow-xl py-1 z-50">
                  {link.sub.map((sub) => (
                    <Link
                      key={sub.href}
                      href={sub.href}
                      className="block px-4 py-2 text-sm font-display text-[#F5F0E8]/80 hover:text-[#FFD600] hover:bg-[#FFD600]/10 transition-colors"
                    >
                      {sub.label}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          ))}
        </nav>

        {/* Right Actions */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Search */}
          <button
            onClick={() => toast.info("Search coming soon — try not to panic.")}
            className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded bg-[#1A1A1A] border border-[#333] text-[#555] hover:text-[#FFD600] hover:border-[#FFD600]/40 transition-all duration-200 font-mono text-xs"
          >
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
            </svg>
            <span className="hidden lg:block">Search...</span>
          </button>

          {/* Panic Button */}
          <button
            onClick={handlePanic}
            className="font-display font-black text-xs px-3 py-1.5 bg-[#FF4D1C] text-white rounded hover:bg-[#FF4D1C]/80 transition-all duration-200 animate-pulse-glow border border-[#FF4D1C]/50 uppercase tracking-wider"
          >
            🚨 PANIC
          </button>

          {/* Profile */}
          <button
            onClick={() => toast.info("Sign up coming soon. Study now, regret later.")}
            className="w-8 h-8 rounded-full bg-[#1A1A1A] border border-[#333] flex items-center justify-center text-[#555] hover:text-[#FFD600] hover:border-[#FFD600]/40 transition-all duration-200"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>
            </svg>
          </button>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="md:hidden w-8 h-8 flex flex-col items-center justify-center gap-1.5"
            aria-label="Toggle menu"
          >
            <span className={`block w-5 h-0.5 bg-[#F5F0E8] transition-all duration-200 ${menuOpen ? "rotate-45 translate-y-2" : ""}`} />
            <span className={`block w-5 h-0.5 bg-[#F5F0E8] transition-all duration-200 ${menuOpen ? "opacity-0" : ""}`} />
            <span className={`block w-5 h-0.5 bg-[#F5F0E8] transition-all duration-200 ${menuOpen ? "-rotate-45 -translate-y-2" : ""}`} />
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="md:hidden bg-[#0D0D0D] border-t border-[#222] px-4 py-4 space-y-1">
          {navLinks.map((link) => (
            <div key={link.href}>
              <Link
                href={link.href}
                className="block font-display font-600 text-base py-2 text-[#F5F0E8]/80 hover:text-[#FFD600] transition-colors"
              >
                {link.label}
              </Link>
              {link.sub && (
                <div className="pl-4 space-y-1">
                  {link.sub.map((sub) => (
                    <Link
                      key={sub.href}
                      href={sub.href}
                      className="block text-sm py-1.5 text-[#555] hover:text-[#FFD600] transition-colors font-mono"
                    >
                      → {sub.label}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          ))}
          <div className="pt-2 border-t border-[#222]">
            <button
              onClick={handlePanic}
              className="w-full font-display font-black text-sm py-3 bg-[#FF4D1C] text-white rounded uppercase tracking-wider"
            >
              🚨 PANIC MODE
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
