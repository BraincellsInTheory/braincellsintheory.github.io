/* ============================================================
   BiT Textbook Vandalism Components
   Red-pen corrections, sarcastic footnotes, highlighter smears,
   marginal annotations — the signature brand grammar of BiT
   ============================================================ */

import React from "react";

/** Red-pen strikethrough correction */
export function RedPenCorrection({
  original,
  correction,
  className = "",
}: {
  original: string;
  correction: string;
  className?: string;
}) {
  return (
    <span className={`inline-flex flex-col items-start gap-0 ${className}`}>
      <span className="relative font-display text-[#F5F0E8]/40 line-through decoration-[#FF4D1C] decoration-2">
        {original}
      </span>
      <span
        className="font-serif italic text-[#FF4D1C] text-sm"
        style={{ fontFamily: "'Georgia', serif", transform: "rotate(-1deg)" }}
      >
        {correction}
      </span>
    </span>
  );
}

/** Highlighter smear behind text */
export function Highlighter({
  children,
  color = "#FFD600",
  className = "",
}: {
  children: React.ReactNode;
  color?: string;
  className?: string;
}) {
  return (
    <mark
      className={`relative inline px-1 py-0.5 rounded-sm ${className}`}
      style={{
        background: `${color}35`,
        boxShadow: `inset 0 -3px 0 ${color}60`,
        color: "inherit",
        textDecoration: "none",
      }}
    >
      {children}
    </mark>
  );
}

/** Marginal annotation (appears to the left like a teacher's note) */
export function MarginNote({
  children,
  className = "",
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <aside
      className={`font-serif italic text-[#FF4D1C] text-xs leading-relaxed border-l-2 border-[#FF4D1C]/40 pl-2 ${className}`}
      style={{ fontFamily: "'Georgia', serif", transform: "rotate(-0.5deg)" }}
    >
      {children}
    </aside>
  );
}

/** Sarcastic footnote at bottom of section */
export function Footnote({
  number,
  children,
  className = "",
}: {
  number: number;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={`flex items-start gap-2 ${className}`}>
      <sup className="font-mono text-[10px] text-[#555] shrink-0 mt-0.5">{number}</sup>
      <p className="font-body text-xs text-[#444] italic leading-relaxed">{children}</p>
    </div>
  );
}

/** Rubber stamp badge */
export function Stamp({
  children,
  color = "#FF4D1C",
  rotate = -2,
  className = "",
}: {
  children: React.ReactNode;
  color?: string;
  rotate?: number;
  className?: string;
}) {
  return (
    <span
      className={`inline-flex items-center font-mono font-700 text-xs uppercase tracking-widest px-3 py-1.5 border-2 rounded-sm ${className}`}
      style={{
        color,
        borderColor: color,
        transform: `rotate(${rotate}deg)`,
        opacity: 0.85,
        textShadow: `0 0 8px ${color}40`,
      }}
    >
      {children}
    </span>
  );
}

/** Teacher's red-pen annotation block */
export function TeacherNote({
  children,
  className = "",
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={`relative p-4 border-l-4 border-[#FF4D1C] bg-[#FF4D1C]/5 ${className}`}
      style={{ transform: "rotate(-0.3deg)" }}
    >
      <div className="absolute -top-2 -left-2 w-5 h-5 bg-[#FF4D1C] rounded-full flex items-center justify-center">
        <span className="text-white text-[10px] font-black">✗</span>
      </div>
      <p className="font-serif italic text-[#FF4D1C]/80 text-sm leading-relaxed pl-3" style={{ fontFamily: "'Georgia', serif" }}>
        {children}
      </p>
    </div>
  );
}

/** Torn paper divider */
export function TornEdge({
  direction = "bottom",
  bgColor = "#0D0D0D",
  className = "",
}: {
  direction?: "top" | "bottom";
  bgColor?: string;
  className?: string;
}) {
  const path =
    direction === "bottom"
      ? "M0,0 L0,40 Q80,20 160,35 Q240,50 320,30 Q400,10 480,38 Q560,60 640,35 Q720,10 800,40 Q880,65 960,38 Q1040,15 1120,42 Q1200,65 1280,40 L1280,0 Z"
      : "M0,60 L0,0 Q80,20 160,5 Q240,0 320,18 Q400,35 480,8 Q560,0 640,22 Q720,40 800,12 Q880,0 960,20 Q1040,38 1120,10 Q1200,0 1280,22 L1280,60 Z";

  return (
    <div className={`w-full overflow-hidden ${className}`} style={{ height: "60px" }}>
      <svg
        viewBox="0 0 1280 60"
        preserveAspectRatio="none"
        className="w-full h-full"
        style={{ display: "block" }}
      >
        <path d={path} fill={bgColor} />
      </svg>
    </div>
  );
}

/** Asymmetric editorial break — full-bleed highlighter bar */
export function EditorialBreak({
  text,
  color = "#FFD600",
  className = "",
}: {
  text: string;
  color?: string;
  className?: string;
}) {
  return (
    <div
      className={`relative py-6 px-8 overflow-hidden ${className}`}
      style={{ background: `${color}12`, borderLeft: `4px solid ${color}` }}
    >
      <div
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `repeating-linear-gradient(45deg, ${color} 0px, ${color} 1px, transparent 1px, transparent 20px)`,
        }}
      />
      <p
        className="relative font-display font-black text-xl md:text-3xl"
        style={{ color, transform: "rotate(-0.5deg)" }}
      >
        {text}
      </p>
    </div>
  );
}
