/* BiT About Page */
import { Link } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const MASCOT = "https://d2xsxph8kpxj0f.cloudfront.net/310519663765059109/J3DCNwY54D46DrPmWoXEao/bit-mascot-foiXwGMD3u4kQGd5fcyeGP.webp";

const values = [
  { icon: "🧠", title: "Honest Education", desc: "We don't pretend learning is easy. We pretend it's survivable. There's a difference." },
  { icon: "😤", title: "Radical Sarcasm", desc: "Because sometimes the only way to get through a 3-hour study session is to laugh at how absurd it is." },
  { icon: "🤝", title: "Actual Community", desc: "Not just a comment section. A place where students help each other not fail." },
  { icon: "🆓", title: "Free. Always.", desc: "Education shouldn't cost your entire summer job paycheck. We're a nonprofit. Deal with it." },
];

const timeline = [
  { year: "2023", event: "BiT was founded by three students who were tired of paying $40/month for flashcard apps." },
  { year: "2024", event: "Launched Panic Mode after a viral tweet about exam anxiety. 50,000 users in 48 hours." },
  { year: "2025", event: "Reached 500,000 students. Added community features, planner, and the blog." },
  { year: "2026", event: "You're here. We're still going. Somehow." },
];

export default function About() {
  return (
    <div className="min-h-screen bg-[#0D0D0D]">
      <Navbar />

      <section className="pt-28 pb-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_#FFD60008_0%,_transparent_60%)]" />
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="bit-stamp text-[#FFD600] border-[#FFD600] mb-6 inline-block">Our story</span>
              <h1 className="font-display font-black text-5xl md:text-7xl text-[#F5F0E8] leading-tight mb-6">
                ABOUT<br /><span className="text-[#FFD600]">BiT</span>
              </h1>
              <p className="font-body text-lg text-[#F5F0E8]/70 leading-relaxed mb-4">
                BRAINCELLS IN THEORY started as a joke between three students who were failing their exams and couldn't afford the study apps everyone was recommending.
              </p>
              <p className="font-body text-lg text-[#F5F0E8]/70 leading-relaxed mb-4">
                The name came from a 2am conversation: "We have braincells in theory. In practice, we have this website."
              </p>
              <p className="font-body text-lg text-[#F5F0E8]/70 leading-relaxed">
                We're a student nonprofit. Everything is free. The sarcasm is also free. You're welcome.
              </p>
            </div>
            <div className="flex justify-center">
              <img src={MASCOT} alt="Brainy" className="w-72 h-72 object-contain animate-float" />
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 bg-[#080808]">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <h2 className="font-display font-black text-3xl text-[#F5F0E8] mb-8">What We Believe</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {values.map((v) => (
              <div key={v.title} className="p-5 rounded-xl border border-[#1A1A1A] bg-[#111]">
                <div className="text-3xl mb-3">{v.icon}</div>
                <h3 className="font-display font-700 text-base text-[#FFD600] mb-2">{v.title}</h3>
                <p className="font-body text-sm text-[#555] leading-relaxed">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-16">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <h2 className="font-display font-black text-3xl text-[#F5F0E8] mb-8">Our Timeline</h2>
          <div className="space-y-4">
            {timeline.map((t) => (
              <div key={t.year} className="flex gap-6 items-start">
                <div className="font-display font-black text-2xl text-[#FFD600] w-16 shrink-0">{t.year}</div>
                <div className="flex-1 pt-1 pb-4 border-b border-[#1A1A1A]">
                  <p className="font-body text-[#F5F0E8]/70">{t.event}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-[#FFD600]">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 text-center">
          <h2 className="font-display font-black text-4xl text-[#0D0D0D] mb-4">Join the Chaos.</h2>
          <p className="font-body text-[#0D0D0D]/60 mb-6">500,000 students already have. They're fine. Mostly.</p>
          <Link href="/subjects" className="inline-flex items-center gap-2 px-8 py-3 bg-[#0D0D0D] text-[#FFD600] font-display font-black text-sm uppercase tracking-wider rounded hover:bg-[#0D0D0D]/80 transition-all">
            Start Studying →
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}
