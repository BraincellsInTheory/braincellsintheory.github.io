/* ============================================================
   BiT Blog — Procrastinate productively
   Handles both /blog (list) and /blog/:slug (article detail)
   ============================================================ */
import { useState } from "react";
import { Link, useParams } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Highlighter, Stamp, TeacherNote, EditorialBreak } from "@/components/TextbookVandalism";

const articles = [
  {
    slug: "ranking-subjects-by-pain",
    title: "Ranking Every School Subject by How Much It Hurts",
    excerpt: "A completely objective, scientifically rigorous ranking of academic subjects based on the amount of psychological damage they cause. Spoiler: Calculus wins.",
    category: "Opinion",
    categoryColor: "#FF4D1C",
    time: "7 min",
    date: "Jun 10, 2026",
    featured: true,
    content: `
Let's be honest. Some subjects are harder than others. And by "harder" I mean "more likely to make you question your life choices at 2am."

**5th Place: English Literature**

English is deceptively hard. You think it's easy — you speak English, right? Wrong. You speak English. You do not speak *Symbolism*. The green light in The Great Gatsby is not just a green light. It never was. It never will be. The green light represents the American Dream, the unattainable nature of desire, and your teacher's desire to see you suffer.

**4th Place: History**

History is just memorizing things that already happened. How hard can it be? Very hard, as it turns out, because there are a lot of things that happened. All of them are on the test. All of them have dates. The dates are important. You will forget the dates.

**3rd Place: Chemistry**

Chemistry is where math and science had a child and that child hates you. Balancing equations is fine. Stoichiometry is fine. But then they introduce thermodynamics and suddenly you're calculating the entropy of your own academic career.

**2nd Place: Physics**

Physics is applied mathematics with extra steps. The extra steps involve vectors, which are arrows that point in directions that will ruin your GPA. Newton invented calculus specifically to do physics, which means he invented two terrible things at once.

**1st Place: Calculus**

Calculus is the final boss. It exists to filter students. It was invented by two people who couldn't agree on who invented it, which tells you everything you need to know about the field. Derivatives are fine. Integrals are fine. But then you hit series convergence and something inside you just... stops.

*The verdict: All subjects hurt. Some just hurt more efficiently.*
    `,
  },
  {
    slug: "how-i-passed-finals",
    title: "How I Passed Finals With 48 Hours of Studying",
    excerpt: "Not a flex. A cautionary tale. But also a guide. Mostly a cautionary tale.",
    category: "Study Tips",
    categoryColor: "#00E5A0",
    time: "5 min",
    date: "Jun 5, 2026",
    featured: true,
    content: `
I want to be clear: this is not a guide on how to study. This is a guide on how to survive when you haven't studied and now you have to.

**Hour 0-4: The Denial Phase**

You know you should study. You are not studying. You are reading this article, which means you are in the denial phase. That's okay. The denial phase is important. It gives your brain time to accept the reality of the situation.

**Hour 4-12: The Bargaining Phase**

You start studying. You realize you don't understand anything. You make deals with yourself: "If I get through this chapter, I'll take a 10-minute break." The 10-minute break becomes 2 hours. This is normal.

**Hour 12-24: The Actual Studying Phase**

This is where it gets real. You stop looking at your phone. You make flashcards. You do practice problems. You eat something that isn't just coffee. This is the phase where studying actually happens.

**Hour 24-36: The Panic Phase**

You realize you don't know enough. You try to learn everything at once. This doesn't work. Focus on the high-yield topics — the things most likely to be on the test. Read the chapter summaries. Do the practice problems at the end of each chapter.

**Hour 36-48: The Acceptance Phase**

You know what you know. You don't know what you don't know. You sleep for 6 hours because your brain consolidates memory during sleep and you need every advantage you can get.

**Result: I passed.**

Not with flying colors. Not with a grade I'm proud of. But I passed. And sometimes that's enough.

*The moral: Start earlier. But if you can't, this works too.*
    `,
  },
  {
    slug: "why-calculus-exists",
    title: "Why Calculus Exists (And Who to Blame)",
    excerpt: "A brief history of how Newton and Leibniz independently invented calculus and ruined millions of students' GPAs for centuries to come.",
    category: "History of Math",
    categoryColor: "#7B61FF",
    time: "6 min",
    date: "May 28, 2026",
    featured: false,
    content: `
In the 17th century, two men independently invented calculus. This is either a remarkable coincidence or evidence that the universe wanted students to suffer.

**Isaac Newton** invented calculus (he called it "the method of fluxions") to solve problems in physics. He needed a way to calculate instantaneous rates of change. He did not think about what this would do to high school students 400 years later.

**Gottfried Wilhelm Leibniz** also invented calculus, independently, around the same time. He developed the notation we still use today: dy/dx, ∫, and the rest of the symbols that appear in your nightmares.

**The Priority Dispute**

Newton and Leibniz spent years arguing about who invented calculus first. This dispute divided the mathematical community for decades. The British used Newton's notation; the Europeans used Leibniz's. British mathematics fell behind as a result. This is what happens when you let ego get in the way of progress.

**Why It Matters**

Calculus is the language of change. Physics, engineering, economics, biology — all of them use calculus. The derivative tells you how fast something is changing. The integral tells you how much has accumulated. These are genuinely useful things to know.

That doesn't make it less hard. But it does make it less pointless.

*The verdict: Blame Newton and Leibniz equally. They both did this to you.*
    `,
  },
  {
    slug: "books-ranked-trauma",
    title: "Every Book You'll Read in High School, Ranked by Trauma",
    excerpt: "From mildly concerning to 'I need therapy after this.' A comprehensive ranking of required reading.",
    category: "English",
    categoryColor: "#FFD600",
    time: "8 min",
    date: "May 20, 2026",
    featured: false,
    content: `
Required reading exists to expose students to great literature. It also exists to make them feel things they didn't ask to feel. Here's a ranking.

**Tier 1: Mildly Concerning**
*Romeo and Juliet* — Two teenagers make terrible decisions. Everyone dies. The lesson is unclear.

**Tier 2: Emotionally Damaging**
*Of Mice and Men* — You will cry. You know you will cry. You cry anyway.

**Tier 3: Existentially Destabilizing**
*1984* — After reading this, you will be paranoid about surveillance for the rest of your life. This is the intended effect.

**Tier 4: Requires Therapy**
*The Road* — There is no hope. There is only the road. And the boy. And the ash.

*The verdict: All of these are worth reading. None of them are comfortable.*
    `,
  },
  {
    slug: "chemistry-gpa",
    title: "Chemistry vs. Your GPA: A Love Story",
    excerpt: "They met in 9th grade. It was complicated. It was always complicated.",
    category: "Science",
    categoryColor: "#00E5A0",
    time: "4 min",
    date: "May 15, 2026",
    featured: false,
    content: `
Chapter 1: The Meeting

You met Chemistry in 9th grade. It seemed simple at first. Elements. The periodic table. Naming compounds. You thought: I can do this.

Chapter 2: The Complication

Then came stoichiometry. Mole ratios. Limiting reagents. Your GPA started to waver.

Chapter 3: The Crisis

AP Chemistry. Thermodynamics. Electrochemistry. Quantum mechanics. Your GPA did not survive.

Chapter 4: The Resolution

You passed. Barely. But you passed. And somewhere in the wreckage, you learned that matter is made of atoms and atoms are mostly empty space, which is either comforting or terrifying depending on your perspective.

*The verdict: Chemistry and your GPA will never be friends. But they can coexist.*
    `,
  },
  {
    slug: "history-dates-guide",
    title: "How to Actually Remember History Dates",
    excerpt: "Mnemonics, patterns, and the dark art of making dates stick in your brain.",
    category: "Study Tips",
    categoryColor: "#00E5A0",
    time: "5 min",
    date: "May 10, 2026",
    featured: false,
    content: `
History dates are hard to memorize because they're arbitrary. 1776 doesn't feel like anything. 1914 doesn't feel like anything. They're just numbers.

**The Mnemonic Method**

Create a story or image that connects the date to the event. 1776: "Seven sevens and a six walked into a revolution." Ridiculous? Yes. Memorable? Also yes.

**The Pattern Method**

Look for patterns. WWI started in 1914, ended in 1918. WWII started in 1939, ended in 1945. The gaps are meaningful: 4 years, 6 years. Patterns are easier to remember than isolated facts.

**The Context Method**

Understand why things happened when they did. The French Revolution (1789) happened partly because of the American Revolution (1776). Connecting events creates a web of memory.

**The Practice Method**

Write dates down. Test yourself. Use flashcards. Spaced repetition works. It's boring, but it works.

*The verdict: There's no shortcut. But there are better paths.*
    `,
  },
];

const categories = ["All", "Study Tips", "Opinion", "Science", "History", "English", "Writing", "Productivity", "History of Math"];

function BlogList() {
  const [activeCategory, setActiveCategory] = useState("All");
  const filtered = activeCategory === "All" ? articles : articles.filter((a) => a.category === activeCategory);
  const featured = articles.filter((a) => a.featured);
  const rest = filtered.filter((a) => !a.featured);

  return (
    <div className="min-h-screen bg-[#0D0D0D]">
      <Navbar />
      <section className="pt-28 pb-12 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,_#FFD60008_0%,_transparent_60%)]" />
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <span className="bit-stamp text-[#FFD600] border-[#FFD600] mb-4 inline-block">Procrastinate productively</span>
          <div className="flex items-start gap-4">
            <h1 className="font-display font-black text-5xl md:text-7xl text-[#F5F0E8] mb-4">
              THE <span className="text-[#FFD600]">BLOG</span>
            </h1>
            <div className="hidden md:block mt-3">
              <Stamp color="#FF4D1C" rotate={2}>Not studying</Stamp>
            </div>
          </div>
          <p className="font-body text-xl text-[#555]">Articles you'll read <Highlighter color="#FFD600">instead of studying</Highlighter>. You're welcome.</p>
        </div>
      </section>

      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 pb-16">
        {activeCategory === "All" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-10">
            {featured.map((article) => (
              <Link
                key={article.slug}
                href={`/blog/${article.slug}`}
                className="group relative rounded-xl border border-[#1A1A1A] bg-[#111] overflow-hidden hover:border-[#FFD600]/30 transition-all duration-300"
              >
                <div className="p-6">
                  <div className="flex items-center gap-2 mb-3">
                    <span className="bit-stamp text-xs" style={{ color: article.categoryColor, borderColor: `${article.categoryColor}50` }}>
                      {article.category}
                    </span>
                    <span className="font-mono text-xs text-[#333]">FEATURED</span>
                  </div>
                  <h2 className="font-display font-black text-xl text-[#F5F0E8] mb-3 group-hover:text-[#FFD600] transition-colors leading-tight">
                    {article.title}
                  </h2>
                  <p className="font-body text-sm text-[#555] leading-relaxed mb-4">{article.excerpt}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="font-mono text-xs text-[#333]">{article.date}</span>
                      <span className="font-mono text-xs text-[#333]">⏱ {article.time}</span>
                    </div>
                    <span className="font-display font-700 text-xs text-[#FFD600] opacity-0 group-hover:opacity-100 transition-opacity">Read →</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}

        <div className="flex flex-wrap gap-2 mb-8">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className="font-mono text-xs px-3 py-1.5 rounded border transition-all duration-200"
              style={{
                borderColor: activeCategory === cat ? "#FFD600" : "#333",
                color: activeCategory === cat ? "#FFD600" : "#555",
                background: activeCategory === cat ? "#FFD60015" : "transparent",
              }}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {(activeCategory === "All" ? rest : filtered).map((article) => (
            <Link
              key={article.slug}
              href={`/blog/${article.slug}`}
              className="group p-5 rounded-xl border border-[#1A1A1A] bg-[#111] hover:border-[#FFD600]/20 transition-all duration-300"
            >
              <div className="flex items-center gap-2 mb-3">
                <span className="bit-stamp text-[10px]" style={{ color: article.categoryColor, borderColor: `${article.categoryColor}50` }}>
                  {article.category}
                </span>
              </div>
              <h3 className="font-display font-700 text-base text-[#F5F0E8] mb-2 group-hover:text-[#FFD600] transition-colors leading-snug">
                {article.title}
              </h3>
              <p className="font-body text-xs text-[#555] leading-relaxed mb-4">{article.excerpt}</p>
              <div className="flex items-center justify-between">
                <span className="font-mono text-xs text-[#333]">⏱ {article.time} read</span>
                <span className="font-mono text-xs text-[#333]">{article.date}</span>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Editorial break */}
      <EditorialBreak
        text='"Reading this blog counts as studying. We said so." — BiT Legal Team'
        color="#7B61FF"
        className="mx-4 sm:mx-8 mb-12"
      />

      <Footer />
    </div>
  );
}

function BlogArticle({ slug }: { slug: string }) {
  const article = articles.find((a) => a.slug === slug);

  if (!article) {
    return (
      <div className="min-h-screen bg-[#0D0D0D]">
        <Navbar />
        <div className="pt-28 max-w-[1280px] mx-auto px-4 sm:px-6 text-center py-24">
          <div className="text-6xl mb-4">🔍</div>
          <h1 className="font-display font-black text-4xl text-[#F5F0E8] mb-4">Article Not Found</h1>
          <p className="font-body text-[#555] mb-8">That article doesn't exist. Yet. Maybe write it?</p>
          <Link href="/blog" className="font-display font-700 text-sm text-[#FFD600] hover:underline">← Back to Blog</Link>
        </div>
        <Footer />
      </div>
    );
  }

  const paragraphs = article.content.trim().split("\n\n");

  return (
    <div className="min-h-screen bg-[#0D0D0D]">
      <Navbar />
      <article className="pt-28 pb-16">
        <div className="max-w-[720px] mx-auto px-4 sm:px-6">
          {/* Back */}
          <Link href="/blog" className="inline-flex items-center gap-2 font-mono text-xs text-[#555] hover:text-[#FFD600] transition-colors mb-8">
            ← Back to Blog
          </Link>

          {/* Header */}
          <div className="mb-10">
            <div className="flex items-center gap-3 mb-4">
              <span className="bit-stamp text-xs" style={{ color: article.categoryColor, borderColor: `${article.categoryColor}50` }}>
                {article.category}
              </span>
              <span className="font-mono text-xs text-[#333]">{article.date}</span>
              <span className="font-mono text-xs text-[#333]">⏱ {article.time} read</span>
            </div>
            <h1 className="font-display font-black text-3xl md:text-5xl text-[#F5F0E8] leading-tight mb-4">
              {article.title}
            </h1>
            <p className="font-body text-lg text-[#555] leading-relaxed italic">{article.excerpt}</p>
          </div>

          {/* Divider */}
          <div className="h-px bg-gradient-to-r from-transparent via-[#333] to-transparent mb-10" />

          {/* Content */}
          <div className="space-y-5">
            {paragraphs.map((para, i) => {
              if (para.startsWith("**") && para.endsWith("**")) {
                return (
                  <h2 key={i} className="font-display font-black text-xl text-[#FFD600] mt-8">
                    {para.replace(/\*\*/g, "")}
                  </h2>
                );
              }
              if (para.startsWith("*") && para.endsWith("*")) {
                return (
                  <p key={i} className="font-body text-sm text-[#555] italic border-l-2 border-[#333] pl-4">
                    {para.replace(/\*/g, "")}
                  </p>
                );
              }
              // Handle inline bold
              const parts = para.split(/(\*\*[^*]+\*\*)/g);
              return (
                <p key={i} className="font-body text-base text-[#F5F0E8]/80 leading-relaxed">
                  {parts.map((part, j) => {
                    if (part.startsWith("**") && part.endsWith("**")) {
                      return <strong key={j} className="text-[#F5F0E8] font-display font-700">{part.replace(/\*\*/g, "")}</strong>;
                    }
                    return part;
                  })}
                </p>
              );
            })}
          </div>

          {/* Footer */}
          <div className="mt-12 pt-8 border-t border-[#1A1A1A]">
            <h3 className="font-display font-700 text-sm text-[#F5F0E8] mb-4">More from the blog</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {articles.filter((a) => a.slug !== slug).slice(0, 2).map((a) => (
                <Link
                  key={a.slug}
                  href={`/blog/${a.slug}`}
                  className="p-4 rounded-lg border border-[#1A1A1A] bg-[#111] hover:border-[#FFD600]/20 transition-all"
                >
                  <h4 className="font-display font-700 text-sm text-[#F5F0E8] mb-1 hover:text-[#FFD600] transition-colors leading-snug">
                    {a.title}
                  </h4>
                  <span className="font-mono text-xs text-[#333]">⏱ {a.time} read</span>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </article>
      <Footer />
    </div>
  );
}

export default function Blog() {
  const params = useParams<{ slug?: string }>();
  if (params.slug) {
    return <BlogArticle slug={params.slug} />;
  }
  return <BlogList />;
}
