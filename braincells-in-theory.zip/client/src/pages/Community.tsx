/* BiT Community Page */
import { useState } from "react";
import { Link } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { toast } from "sonner";

const events = [
  { title: "Finals Survival Workshop", date: "Jun 20, 2026", type: "Workshop", attendees: 234, color: "#FF4D1C" },
  { title: "Math Olympiad Prep Session", date: "Jun 25, 2026", type: "Study Group", attendees: 89, color: "#7B61FF" },
  { title: "Essay Writing Masterclass", date: "Jul 2, 2026", type: "Workshop", attendees: 156, color: "#FFD600" },
  { title: "BiT Community Meetup", date: "Jul 10, 2026", type: "Community", attendees: 412, color: "#00E5A0" },
];

const leaderboard = [
  { rank: 1, name: "Alex K.", xp: 12450, badge: "🏆", streak: 45 },
  { rank: 2, name: "Sam T.", xp: 11200, badge: "🥈", streak: 38 },
  { rank: 3, name: "Jordan M.", xp: 9800, badge: "🥉", streak: 30 },
  { rank: 4, name: "Riley P.", xp: 8600, badge: "⭐", streak: 22 },
  { rank: 5, name: "Casey L.", xp: 7900, badge: "⭐", streak: 18 },
];

const features = [
  { icon: "👥", title: "Study Circles", desc: "Form groups with students studying the same subjects. Suffer together." },
  { icon: "🎓", title: "Mentorship", desc: "Get paired with a student who survived what you're going through." },
  { icon: "📅", title: "Events", desc: "Workshops, study sessions, and community meetups." },
  { icon: "🏆", title: "Leaderboard", desc: "Compete for XP. Because gamification makes everything better." },
  { icon: "📤", title: "Resource Sharing", desc: "Upload your notes. Download theirs. The circle of academic life." },
  { icon: "🤝", title: "Volunteer Hub", desc: "Help other students. It's good karma. And it looks great on applications." },
];

export default function Community() {
  const [tab, setTab] = useState<"events" | "leaderboard" | "features">("features");

  return (
    <div className="min-h-screen bg-[#0D0D0D]">
      <Navbar />

      <section className="pt-28 pb-12 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_#00E5A015_0%,_transparent_60%)]" />
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <span className="bit-stamp text-[#00E5A0] border-[#00E5A0] mb-4 inline-block">Misery loves company</span>
          <h1 className="font-display font-black text-5xl md:text-7xl text-[#F5F0E8] mb-4">
            COMMUNITY
          </h1>
          <p className="font-body text-xl text-[#555]">500,000 students. All of them slightly panicking. Join us.</p>
        </div>
      </section>

      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 pb-16">
        {/* Tabs */}
        <div className="flex gap-2 mb-8 border-b border-[#1A1A1A] pb-4">
          {(["features", "events", "leaderboard"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className="font-display font-700 text-sm px-4 py-2 rounded capitalize transition-all"
              style={{
                background: tab === t ? "#00E5A0" : "transparent",
                color: tab === t ? "#0D0D0D" : "#555",
              }}
            >
              {t}
            </button>
          ))}
        </div>

        {tab === "features" && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {features.map((f) => (
              <div
                key={f.title}
                className="p-5 rounded-xl border border-[#1A1A1A] bg-[#111] hover:border-[#00E5A0]/30 transition-all cursor-pointer"
                onClick={() => toast.info(`${f.title} coming soon!`)}
              >
                <div className="text-3xl mb-3">{f.icon}</div>
                <h3 className="font-display font-700 text-base text-[#F5F0E8] mb-2">{f.title}</h3>
                <p className="font-body text-sm text-[#555] leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        )}

        {tab === "events" && (
          <div className="space-y-4">
            {events.map((event) => (
              <div
                key={event.title}
                className="flex items-center justify-between p-5 rounded-xl border border-[#1A1A1A] bg-[#111] hover:border-current transition-all"
                onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = `${event.color}40`; }}
                onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = "#1A1A1A"; }}
              >
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="bit-stamp text-xs" style={{ color: event.color, borderColor: `${event.color}50` }}>
                      {event.type}
                    </span>
                  </div>
                  <h3 className="font-display font-700 text-base text-[#F5F0E8]">{event.title}</h3>
                  <p className="font-mono text-xs text-[#555] mt-1">📅 {event.date} · 👥 {event.attendees} attending</p>
                </div>
                <button
                  onClick={() => toast.success(`RSVP'd to ${event.title}!`)}
                  className="px-4 py-2 rounded font-display font-700 text-sm transition-all"
                  style={{ background: event.color, color: "#0D0D0D" }}
                >
                  RSVP
                </button>
              </div>
            ))}
          </div>
        )}

        {tab === "leaderboard" && (
          <div>
            <div className="space-y-3">
              {leaderboard.map((user) => (
                <div
                  key={user.rank}
                  className={`flex items-center gap-4 p-4 rounded-xl border transition-all ${
                    user.rank === 1 ? "border-[#FFD600]/40 bg-[#FFD600]/8" : "border-[#1A1A1A] bg-[#111]"
                  }`}
                >
                  <span className="font-display font-black text-2xl w-8 text-center">{user.badge}</span>
                  <div className="flex-1">
                    <div className="font-display font-700 text-sm text-[#F5F0E8]">{user.name}</div>
                    <div className="font-mono text-xs text-[#555]">🔥 {user.streak} day streak</div>
                  </div>
                  <div className="text-right">
                    <div className="font-display font-black text-lg text-[#FFD600]">{user.xp.toLocaleString()}</div>
                    <div className="font-mono text-xs text-[#555]">XP</div>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-6 p-4 rounded-xl border border-[#1A1A1A] bg-[#111] text-center">
              <p className="font-mono text-xs text-[#555]">Your rank: #4,821 · 1,240 XP</p>
              <button
                onClick={() => toast.info("Sign up to track your progress!")}
                className="mt-3 px-4 py-2 bg-[#FFD600] text-[#0D0D0D] font-display font-700 text-xs rounded hover:bg-[#FFD600]/80 transition-all"
              >
                Join the Leaderboard
              </button>
            </div>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
