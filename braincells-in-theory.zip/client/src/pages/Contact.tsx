/* BiT Contact Page */
import { useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { toast } from "sonner";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", subject: "General", message: "" });
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) {
      toast.error("Please fill in all fields. We can't reply to nothing.");
      return;
    }
    setSent(true);
    toast.success("Message sent! We'll reply within 48 hours. Probably.");
  };

  const contacts = [
    { icon: "📧", label: "Email", value: "hello@braincellsintheory.com" },
    { icon: "🐦", label: "Twitter", value: "@braincellsbit" },
    { icon: "📸", label: "Instagram", value: "@braincellsintheory" },
    { icon: "💬", label: "Discord", value: "discord.gg/braincellsbit" },
  ];

  return (
    <div className="min-h-screen bg-[#0D0D0D]">
      <Navbar />
      <section className="pt-28 pb-12">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <span className="bit-stamp text-[#00E5A0] border-[#00E5A0] mb-4 inline-block">We read these. Sometimes.</span>
          <h1 className="font-display font-black text-5xl md:text-7xl text-[#F5F0E8] mb-4">
            CONTACT <span className="text-[#00E5A0]">US</span>
          </h1>
          <p className="font-body text-xl text-[#555]">We're real people. Allegedly.</p>
        </div>
      </section>

      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {/* Form */}
          <div>
            {sent ? (
              <div className="p-8 rounded-xl border border-[#00E5A0]/30 bg-[#00E5A0]/8 text-center">
                <div className="text-5xl mb-4">✉️</div>
                <h3 className="font-display font-black text-2xl text-[#00E5A0] mb-2">Message Sent!</h3>
                <p className="font-body text-[#F5F0E8]/60">We'll get back to you within 48 hours. Unless it's exam season. Then 72.</p>
                <button onClick={() => setSent(false)} className="mt-4 font-mono text-xs text-[#555] hover:text-[#FFD600] transition-colors">
                  Send another →
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="font-mono text-xs text-[#555] uppercase tracking-widest block mb-2">Name</label>
                    <input
                      type="text"
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      placeholder="Your name"
                      className="w-full px-4 py-3 bg-[#111] border border-[#333] rounded text-sm text-[#F5F0E8] placeholder-[#333] focus:outline-none focus:border-[#00E5A0]/50 font-body"
                    />
                  </div>
                  <div>
                    <label className="font-mono text-xs text-[#555] uppercase tracking-widest block mb-2">Email</label>
                    <input
                      type="email"
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      placeholder="your@email.com"
                      className="w-full px-4 py-3 bg-[#111] border border-[#333] rounded text-sm text-[#F5F0E8] placeholder-[#333] focus:outline-none focus:border-[#00E5A0]/50 font-body"
                    />
                  </div>
                </div>
                <div>
                  <label className="font-mono text-xs text-[#555] uppercase tracking-widest block mb-2">Subject</label>
                  <select
                    value={form.subject}
                    onChange={(e) => setForm({ ...form, subject: e.target.value })}
                    className="w-full px-4 py-3 bg-[#111] border border-[#333] rounded text-sm text-[#F5F0E8] focus:outline-none focus:border-[#00E5A0]/50 font-body"
                  >
                    <option value="General">General Inquiry</option>
                    <option value="Bug">Bug Report</option>
                    <option value="Content">Content Issue</option>
                    <option value="Partnership">Partnership</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="font-mono text-xs text-[#555] uppercase tracking-widest block mb-2">Message</label>
                  <textarea
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    placeholder="What's on your mind? (Besides exam anxiety)"
                    rows={5}
                    className="w-full px-4 py-3 bg-[#111] border border-[#333] rounded text-sm text-[#F5F0E8] placeholder-[#333] focus:outline-none focus:border-[#00E5A0]/50 font-body resize-none"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-3 bg-[#00E5A0] text-[#0D0D0D] font-display font-black text-sm uppercase tracking-wider rounded hover:bg-[#00E5A0]/80 transition-all"
                >
                  Send Message →
                </button>
              </form>
            )}
          </div>

          {/* Contact info */}
          <div className="space-y-4">
            <h2 className="font-display font-black text-2xl text-[#F5F0E8] mb-6">Other Ways to Reach Us</h2>
            {contacts.map((c) => (
              <div key={c.label} className="flex items-center gap-4 p-4 rounded-xl border border-[#1A1A1A] bg-[#111]">
                <span className="text-2xl">{c.icon}</span>
                <div>
                  <div className="font-mono text-xs text-[#555] uppercase tracking-widest">{c.label}</div>
                  <div className="font-display font-600 text-sm text-[#F5F0E8]">{c.value}</div>
                </div>
              </div>
            ))}
            <div className="p-5 rounded-xl border border-[#FFD600]/30 bg-[#FFD600]/8 mt-6">
              <h3 className="font-display font-700 text-sm text-[#FFD600] mb-2">Response Time</h3>
              <p className="font-body text-sm text-[#F5F0E8]/60">
                We typically respond within 24-48 hours. During finals season, add 3-5 business days. We're students too.
              </p>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
