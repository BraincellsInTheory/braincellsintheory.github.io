/* BiT Developer / API Page */
import { useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { toast } from "sonner";

const endpoints = [
  { method: "GET", path: "/api/v1/subjects", desc: "List all subjects", auth: false },
  { method: "GET", path: "/api/v1/subjects/:slug/topics", desc: "Get topics for a subject", auth: false },
  { method: "GET", path: "/api/v1/guides", desc: "List all study guides", auth: false },
  { method: "GET", path: "/api/v1/guides/:slug", desc: "Get a specific study guide", auth: false },
  { method: "GET", path: "/api/v1/flashcards/:deckId", desc: "Get flashcard deck", auth: true },
  { method: "POST", path: "/api/v1/quiz/generate", desc: "Generate a quiz", auth: true },
  { method: "GET", path: "/api/v1/user/progress", desc: "Get user progress", auth: true },
  { method: "POST", path: "/api/v1/user/progress", desc: "Update user progress", auth: true },
];

const methodColors: Record<string, string> = { GET: "#00E5A0", POST: "#7B61FF", PUT: "#FFD600", DELETE: "#FF4D1C" };

const codeExample = `// BiT API Example
const response = await fetch('https://api.braincellsintheory.com/v1/subjects', {
  headers: {
    'Authorization': 'Bearer YOUR_API_KEY',
    'Content-Type': 'application/json'
  }
});

const subjects = await response.json();
// Returns: [{ slug: "math", name: "Mathematics", topics: [...] }, ...]`;

export default function Developer() {
  const [apiKey] = useState("bit_demo_xxxxxxxxxxxxxxxxxxxx");
  const [copied, setCopied] = useState(false);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    toast.success("Copied to clipboard.");
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-[#0D0D0D]">
      <Navbar />
      <section className="pt-28 pb-12">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <span className="bit-stamp text-[#7B61FF] border-[#7B61FF] mb-4 inline-block">Build with BiT</span>
          <h1 className="font-display font-black text-5xl md:text-7xl text-[#F5F0E8] mb-4">
            DEVELOPER <span className="text-[#7B61FF]">API</span>
          </h1>
          <p className="font-body text-xl text-[#555]">
            Access BiT's content programmatically. Because why not.
          </p>
        </div>
      </section>

      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left: Docs */}
          <div className="lg:col-span-2 space-y-8">
            {/* Getting Started */}
            <div className="p-6 rounded-xl border border-[#1A1A1A] bg-[#111]">
              <h2 className="font-display font-black text-xl text-[#F5F0E8] mb-4">Getting Started</h2>
              <p className="font-body text-sm text-[#555] mb-4">
                The BiT API is RESTful. All responses are JSON. Authentication uses Bearer tokens.
                Base URL: <code className="font-mono text-[#7B61FF] text-xs">https://api.braincellsintheory.com/v1</code>
              </p>
              <div className="relative">
                <pre className="bg-[#0D0D0D] border border-[#333] rounded p-4 font-mono text-xs text-[#F5F0E8]/70 overflow-x-auto leading-relaxed">
                  {codeExample}
                </pre>
                <button
                  onClick={() => handleCopy(codeExample)}
                  className="absolute top-3 right-3 font-mono text-xs text-[#555] hover:text-[#FFD600] transition-colors"
                >
                  {copied ? "✓" : "Copy"}
                </button>
              </div>
            </div>

            {/* Endpoints */}
            <div>
              <h2 className="font-display font-black text-xl text-[#F5F0E8] mb-4">Endpoints</h2>
              <div className="space-y-2">
                {endpoints.map((ep) => (
                  <div
                    key={ep.path}
                    className="flex items-center gap-4 p-4 rounded-lg border border-[#1A1A1A] bg-[#111] hover:border-[#333] transition-all"
                  >
                    <span
                      className="font-mono text-xs px-2 py-0.5 rounded shrink-0 w-12 text-center"
                      style={{ color: methodColors[ep.method], background: `${methodColors[ep.method]}15` }}
                    >
                      {ep.method}
                    </span>
                    <code className="font-mono text-xs text-[#F5F0E8]/70 flex-1">{ep.path}</code>
                    <span className="font-body text-xs text-[#555] hidden md:block">{ep.desc}</span>
                    {ep.auth && (
                      <span className="font-mono text-[10px] text-[#FFD600] border border-[#FFD600]/30 px-1.5 py-0.5 rounded shrink-0">
                        Auth
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right: API Key + Stats */}
          <div className="space-y-4">
            <div className="p-5 rounded-xl border border-[#7B61FF]/30 bg-[#7B61FF]/8">
              <h3 className="font-display font-700 text-sm text-[#7B61FF] mb-3">Your API Key</h3>
              <div className="flex items-center gap-2 mb-3">
                <code className="flex-1 font-mono text-xs text-[#F5F0E8]/60 bg-[#0D0D0D] px-3 py-2 rounded border border-[#333] truncate">
                  {apiKey}
                </code>
                <button
                  onClick={() => handleCopy(apiKey)}
                  className="shrink-0 font-mono text-xs text-[#555] hover:text-[#7B61FF] transition-colors"
                >
                  Copy
                </button>
              </div>
              <p className="font-mono text-[10px] text-[#555]">Demo key. Sign up for production access.</p>
              <button
                onClick={() => toast.info("API sign-up coming soon!")}
                className="mt-3 w-full py-2 bg-[#7B61FF] text-white font-display font-700 text-xs rounded hover:bg-[#7B61FF]/80 transition-all"
              >
                Get Production Key
              </button>
            </div>

            <div className="p-5 rounded-xl border border-[#1A1A1A] bg-[#111]">
              <h3 className="font-display font-700 text-sm text-[#F5F0E8] mb-4">Rate Limits</h3>
              <div className="space-y-2">
                {[
                  { plan: "Free", limit: "100 req/day" },
                  { plan: "Developer", limit: "10,000 req/day" },
                  { plan: "Production", limit: "Unlimited" },
                ].map((p) => (
                  <div key={p.plan} className="flex justify-between text-xs">
                    <span className="font-display font-600 text-[#F5F0E8]/60">{p.plan}</span>
                    <span className="font-mono text-[#555]">{p.limit}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-5 rounded-xl border border-[#1A1A1A] bg-[#111]">
              <h3 className="font-display font-700 text-sm text-[#F5F0E8] mb-3">Resources</h3>
              <div className="space-y-2">
                {[
                  { label: "Full Documentation", href: "#" },
                  { label: "API Changelog", href: "#" },
                  { label: "GitHub SDK", href: "#" },
                  { label: "Postman Collection", href: "#" },
                ].map((r) => (
                  <button
                    key={r.label}
                    onClick={() => toast.info(`${r.label} coming soon!`)}
                    className="w-full text-left font-mono text-xs text-[#555] hover:text-[#7B61FF] transition-colors py-1"
                  >
                    → {r.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
