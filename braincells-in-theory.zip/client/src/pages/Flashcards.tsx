/* ============================================================
   BiT Flashcards — Interactive flip cards with study modes
   ============================================================ */
import { useState } from "react";
import { Link } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { toast } from "sonner";
import { Highlighter, Stamp, EditorialBreak } from "@/components/TextbookVandalism";

const decks = [
  {
    id: "sat-math", name: "SAT Math Essentials", subject: "Math", color: "#7B61FF",
    count: 45, mastered: 12, desc: "The formulas they expect you to know but didn't teach.",
    cards: [
      { front: "Quadratic Formula", back: "x = (-b ± √(b²-4ac)) / 2a\nFor ax² + bx + c = 0" },
      { front: "Slope Formula", back: "m = (y₂ - y₁) / (x₂ - x₁)\nRise over run" },
      { front: "Pythagorean Theorem", back: "a² + b² = c²\nOnly for right triangles" },
      { front: "Area of a Circle", back: "A = πr²\nC = 2πr (circumference)" },
      { front: "Distance Formula", back: "d = √((x₂-x₁)² + (y₂-y₁)²)" },
    ],
  },
  {
    id: "bio-unit-4", name: "Biology Unit 4: Genetics", subject: "Science", color: "#00E5A0",
    count: 38, mastered: 8, desc: "DNA, RNA, and why you look like your parents.",
    cards: [
      { front: "DNA", back: "Deoxyribonucleic acid\nDouble helix structure\nBases: A, T, G, C" },
      { front: "Mitosis", back: "Cell division for growth/repair\nProduces 2 identical diploid cells\nPhases: PMAT" },
      { front: "Meiosis", back: "Cell division for reproduction\nProduces 4 haploid gametes\nPhases: PMAT I & II" },
      { front: "Dominant vs Recessive", back: "Dominant: expressed when present (B)\nRecessive: only expressed when homozygous (bb)" },
      { front: "Phenotype vs Genotype", back: "Genotype: genetic makeup (BB, Bb, bb)\nPhenotype: physical expression (brown eyes)" },
    ],
  },
  {
    id: "ww2-dates", name: "WW2 Key Events", subject: "History", color: "#FF4D1C",
    count: 30, mastered: 20, desc: "Dates, events, and who did what to whom.",
    cards: [
      { front: "September 1, 1939", back: "Germany invades Poland\nWW2 officially begins" },
      { front: "December 7, 1941", back: "Japan attacks Pearl Harbor\nUSA enters WW2" },
      { front: "June 6, 1944", back: "D-Day — Allied invasion of Normandy\nOperation Overlord" },
      { front: "May 8, 1945", back: "V-E Day — Victory in Europe\nGermany surrenders" },
      { front: "August 6-9, 1945", back: "Atomic bombs dropped on Hiroshima and Nagasaki\nJapan surrenders September 2" },
    ],
  },
  {
    id: "lit-devices", name: "Literary Devices", subject: "English", color: "#FFD600",
    count: 25, mastered: 15, desc: "The terms your English teacher expects you to know.",
    cards: [
      { front: "Metaphor", back: "Direct comparison without 'like' or 'as'\nExample: 'Life is a journey'" },
      { front: "Simile", back: "Comparison using 'like' or 'as'\nExample: 'She runs like the wind'" },
      { front: "Alliteration", back: "Repetition of initial consonant sounds\nExample: 'Peter Piper picked...'" },
      { front: "Foreshadowing", back: "Hints at future events in the story\nBuilds suspense and tension" },
      { front: "Irony", back: "Verbal: saying opposite of what you mean\nSituational: opposite of what's expected\nDramatic: audience knows more than characters" },
    ],
  },
];

function FlipCard({ front, back }: { front: string; back: string }) {
  const [flipped, setFlipped] = useState(false);
  return (
    <div
      className="relative w-full cursor-pointer"
      style={{ height: "220px", perspective: "1000px" }}
      onClick={() => setFlipped(!flipped)}
    >
      <div
        className="absolute inset-0 transition-all duration-500"
        style={{
          transformStyle: "preserve-3d",
          transform: flipped ? "rotateY(180deg)" : "rotateY(0deg)",
        }}
      >
        {/* Front */}
        <div
          className="absolute inset-0 flex flex-col items-center justify-center p-6 rounded-xl border border-[#333] bg-[#1A1A1A]"
          style={{ backfaceVisibility: "hidden" }}
        >
          <div className="font-mono text-xs text-[#555] uppercase tracking-widest mb-3">Term</div>
          <div className="font-display font-black text-2xl text-[#F5F0E8] text-center">{front}</div>
          <div className="mt-4 font-mono text-xs text-[#333]">Click to flip</div>
        </div>
        {/* Back */}
        <div
          className="absolute inset-0 flex flex-col items-center justify-center p-6 rounded-xl border border-[#FFD600]/30 bg-[#FFD600]/8"
          style={{ backfaceVisibility: "hidden", transform: "rotateY(180deg)" }}
        >
          <div className="font-mono text-xs text-[#FFD600] uppercase tracking-widest mb-3">Definition</div>
          <pre className="font-body text-sm text-[#F5F0E8]/80 text-center whitespace-pre-wrap leading-relaxed">{back}</pre>
        </div>
      </div>
    </div>
  );
}

export default function Flashcards() {
  const [activeDeck, setActiveDeck] = useState<typeof decks[0] | null>(null);
  const [studyMode, setStudyMode] = useState(false);
  const [cardIndex, setCardIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [known, setKnown] = useState<number[]>([]);
  const [unknown, setUnknown] = useState<number[]>([]);

  const handleStartStudy = (deck: typeof decks[0]) => {
    setActiveDeck(deck);
    setStudyMode(true);
    setCardIndex(0);
    setFlipped(false);
    setKnown([]);
    setUnknown([]);
  };

  const handleKnow = () => {
    setKnown((prev) => [...prev, cardIndex]);
    nextCard();
  };

  const handleDontKnow = () => {
    setUnknown((prev) => [...prev, cardIndex]);
    nextCard();
  };

  const nextCard = () => {
    if (!activeDeck) return;
    if (cardIndex < activeDeck.cards.length - 1) {
      setCardIndex((i) => i + 1);
      setFlipped(false);
    } else {
      toast.success(`Session complete! ${known.length + 1}/${activeDeck.cards.length} known. Not bad.`);
      setStudyMode(false);
    }
  };

  if (studyMode && activeDeck) {
    const card = activeDeck.cards[cardIndex];
    const progress = ((cardIndex) / activeDeck.cards.length) * 100;

    return (
      <div className="min-h-screen bg-[#0D0D0D]">
        <Navbar />
        <div className="max-w-xl mx-auto px-4 pt-24 pb-16">
          {/* Progress */}
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={() => setStudyMode(false)}
              className="font-mono text-xs text-[#555] hover:text-[#FFD600] transition-colors"
            >
              ← Exit
            </button>
            <span className="font-mono text-xs text-[#555]">
              {cardIndex + 1} / {activeDeck.cards.length}
            </span>
          </div>
          <div className="h-1 bg-[#1A1A1A] rounded mb-8 overflow-hidden">
            <div
              className="h-full transition-all duration-300"
              style={{ width: `${progress}%`, background: activeDeck.color }}
            />
          </div>

          {/* Card */}
          <div
            className="relative w-full cursor-pointer mb-6"
            style={{ height: "260px", perspective: "1000px" }}
            onClick={() => setFlipped(!flipped)}
          >
            <div
              className="absolute inset-0 transition-all duration-500"
              style={{
                transformStyle: "preserve-3d",
                transform: flipped ? "rotateY(180deg)" : "rotateY(0deg)",
              }}
            >
              <div
                className="absolute inset-0 flex flex-col items-center justify-center p-8 rounded-xl border border-[#333] bg-[#1A1A1A]"
                style={{ backfaceVisibility: "hidden" }}
              >
                <div className="font-mono text-xs text-[#555] uppercase tracking-widest mb-4">Term</div>
                <div className="font-display font-black text-3xl text-[#F5F0E8] text-center">{card.front}</div>
                <div className="mt-6 font-mono text-xs text-[#333]">Tap to reveal</div>
              </div>
              <div
                className="absolute inset-0 flex flex-col items-center justify-center p-8 rounded-xl"
                style={{
                  backfaceVisibility: "hidden",
                  transform: "rotateY(180deg)",
                  background: `${activeDeck.color}10`,
                  borderColor: `${activeDeck.color}40`,
                  border: `1px solid ${activeDeck.color}40`,
                }}
              >
                <div className="font-mono text-xs uppercase tracking-widest mb-4" style={{ color: activeDeck.color }}>
                  Definition
                </div>
                <pre className="font-body text-sm text-[#F5F0E8]/80 text-center whitespace-pre-wrap leading-relaxed">
                  {card.back}
                </pre>
              </div>
            </div>
          </div>

          {/* Actions */}
          {flipped && (
            <div className="flex gap-3">
              <button
                onClick={handleDontKnow}
                className="flex-1 py-3 rounded border border-[#FF4D1C]/40 text-[#FF4D1C] font-display font-700 text-sm hover:bg-[#FF4D1C]/10 transition-all"
              >
                ✗ Still Learning
              </button>
              <button
                onClick={handleKnow}
                className="flex-1 py-3 rounded border border-[#00E5A0]/40 text-[#00E5A0] font-display font-700 text-sm hover:bg-[#00E5A0]/10 transition-all"
              >
                ✓ Got It
              </button>
            </div>
          )}

          {/* Stats */}
          <div className="flex gap-4 mt-4 justify-center">
            <span className="font-mono text-xs text-[#00E5A0]">✓ {known.length} known</span>
            <span className="font-mono text-xs text-[#FF4D1C]">✗ {unknown.length} learning</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0D0D0D]">
      <Navbar />

      {/* Header */}
      <section className="pt-28 pb-12 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,_#7B61FF15_0%,_transparent_60%)]" />
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <span className="bit-stamp text-[#7B61FF] border-[#7B61FF] mb-4 inline-block">
            Spaced repetition therapy
          </span>
          <div className="flex items-start gap-4">
            <h1 className="font-display font-black text-5xl md:text-7xl text-[#F5F0E8] mb-4">
              FLASH<span className="text-[#7B61FF]">CARDS</span>
            </h1>
            <div className="hidden md:block mt-4">
              <Stamp color="#7B61FF" rotate={-2}>Memorize</Stamp>
            </div>
          </div>
          <p className="font-body text-xl text-[#555] max-w-xl">
            Your memory is <Highlighter color="#FF4D1C">terrible</Highlighter>. These will help. Probably.
          </p>
        </div>
      </section>

      {/* Decks */}
      <section className="pb-24">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-display font-black text-2xl text-[#F5F0E8]">
              Available Decks
            </h2>
            <button
              onClick={() => toast.info("Create custom decks coming soon.")}
              className="font-mono text-xs text-[#555] hover:text-[#FFD600] transition-colors border border-[#333] px-3 py-1.5 rounded hover:border-[#FFD600]/40"
            >
              + Create Deck
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
            {decks.map((deck) => (
              <div
                key={deck.id}
                className="rounded-xl border border-[#1A1A1A] bg-[#111] overflow-hidden hover:border-current transition-all duration-300"
                onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = `${deck.color}40`; }}
                onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = "#1A1A1A"; }}
              >
                <div className="p-5">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <span className="bit-stamp text-xs mb-2 inline-block" style={{ color: deck.color, borderColor: `${deck.color}50` }}>
                        {deck.subject}
                      </span>
                      <h3 className="font-display font-700 text-lg text-[#F5F0E8]">{deck.name}</h3>
                      <p className="font-body text-sm text-[#555] mt-1">{deck.desc}</p>
                    </div>
                  </div>

                  {/* Progress */}
                  <div className="mb-4">
                    <div className="flex justify-between text-xs font-mono text-[#555] mb-1.5">
                      <span>{deck.mastered} mastered</span>
                      <span>{deck.count} total</span>
                    </div>
                    <div className="h-1.5 bg-[#1A1A1A] rounded overflow-hidden">
                      <div
                        className="h-full rounded transition-all duration-500"
                        style={{ width: `${(deck.mastered / deck.count) * 100}%`, background: deck.color }}
                      />
                    </div>
                  </div>

                  <button
                    onClick={() => handleStartStudy(deck)}
                    className="w-full py-2.5 rounded font-display font-700 text-sm uppercase tracking-wider transition-all duration-200"
                    style={{ background: deck.color, color: "#0D0D0D" }}
                  >
                    Study Now →
                  </button>
                </div>

                {/* Preview cards */}
                <div className="border-t border-[#1A1A1A] px-5 py-3 flex gap-2 overflow-x-auto">
                  {deck.cards.slice(0, 3).map((card, i) => (
                    <div
                      key={i}
                      className="shrink-0 px-3 py-1.5 rounded bg-[#1A1A1A] border border-[#222]"
                    >
                      <span className="font-mono text-xs text-[#555]">{card.front}</span>
                    </div>
                  ))}
                  <div className="shrink-0 px-3 py-1.5 rounded bg-[#1A1A1A] border border-[#222]">
                    <span className="font-mono text-xs text-[#333]">+{deck.count - 3} more</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Sample flip cards */}
          <h2 className="font-display font-black text-2xl text-[#F5F0E8] mb-6">
            Try a Card <span className="font-mono text-sm text-[#555] font-normal">— click to flip</span>
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {decks[0].cards.slice(0, 3).map((card, i) => (
              <FlipCard key={i} front={card.front} back={card.back} />
            ))}
          </div>
        </div>
      </section>

      {/* Editorial break */}
      <EditorialBreak
        text='"Spaced repetition is the closest thing to cheating that actually works." — Science'
        color="#7B61FF"
        className="mx-4 sm:mx-8 mb-12"
      />

      <Footer />
    </div>
  );
}
