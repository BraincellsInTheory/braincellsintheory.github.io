/* ============================================================
   BiT Home Page — "Chaotic Textbook Riot"
   Story: Chaos → Discovery → Confidence
   Scrollytelling: floating objects → cards assemble → features explode → CTA zoom
   ============================================================ */
import { useEffect, useRef, useState } from "react";
import { Link } from "wouter";
import { toast } from "sonner";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Highlighter, MarginNote, Footnote, Stamp, TeacherNote, EditorialBreak, TornEdge } from "@/components/TextbookVandalism";

const HERO_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663765059109/J3DCNwY54D46DrPmWoXEao/bit-hero-bg-j2dxmfrFHE2zrs5JMhzWm4.webp";
const MASCOT = "https://d2xsxph8kpxj0f.cloudfront.net/310519663765059109/J3DCNwY54D46DrPmWoXEao/bit-mascot-foiXwGMD3u4kQGd5fcyeGP.webp";
const SUBJECTS_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663765059109/J3DCNwY54D46DrPmWoXEao/bit-subjects-bg-hxPW6iWNEGa8CN6t8YjAVk.webp";

const subjects = [
  { name: "Math", slug: "math", color: "#7B61FF", bg: "#7B61FF15", icon: "∑", desc: "Where your calculator becomes your therapist.", topics: ["Algebra", "Geometry", "Calculus", "Statistics"] },
  { name: "Science", slug: "science", color: "#00E5A0", bg: "#00E5A015", icon: "⚛", desc: "Atoms, molecules, and existential dread.", topics: ["Biology", "Chemistry", "Physics"] },
  { name: "History", slug: "history", color: "#FF4D1C", bg: "#FF4D1C15", icon: "🗺", desc: "Everything that went wrong, in chronological order.", topics: ["World War", "Ancient", "Revolutions"] },
  { name: "English", slug: "english", color: "#FFD600", bg: "#FFD60015", icon: "✍", desc: "Symbolism you didn't ask for but got anyway.", topics: ["Books", "Poetry", "Writing"] },
];

const features = [
  { icon: "📚", title: "Study Guides", desc: "Actual explanations. Not just vibes.", color: "#7B61FF" },
  { icon: "🃏", title: "Flashcards", desc: "Spaced repetition. Your memory's last hope.", color: "#00E5A0" },
  { icon: "🚨", title: "Panic Mode", desc: "Exam in 2 hours? We've got you. Barely.", color: "#FF4D1C" },
  { icon: "📅", title: "Planner", desc: "Schedule your suffering in advance.", color: "#FFD600" },
  { icon: "🧠", title: "AI Summaries", desc: "Let the robots explain what your teacher couldn't.", color: "#7B61FF" },
  { icon: "🏆", title: "Gamification", desc: "XP, streaks, badges. Cope mechanisms, basically.", color: "#00E5A0" },
  { icon: "📝", title: "Quiz Generator", desc: "Test yourself before the test tests you.", color: "#FF4D1C" },
  { icon: "👥", title: "Community", desc: "Misery loves company. Join ours.", color: "#FFD600" },
];

const testimonials = [
  { name: "Alex K.", grade: "11th Grade", text: "I came for a quadratic formula and stayed for 3 hours. Send help.", rating: 5 },
  { name: "Sam T.", grade: "College Freshman", text: "The Panic Mode literally saved my finals. I'm not okay but I passed.", rating: 5 },
  { name: "Jordan M.", grade: "10th Grade", text: "BiT told me I was 'very ahead of being behind.' That hit different.", rating: 5 },
  { name: "Riley P.", grade: "12th Grade", text: "The sarcasm makes the suffering bearable. 10/10 would cry again.", rating: 5 },
];

const stats = [
  { value: "500K+", label: "Students Suffering Together" },
  { value: "10K+", label: "Study Guides Written" },
  { value: "2M+", label: "Flashcards Reviewed" },
  { value: "98%", label: "Panic Mode Survival Rate" },
];

function useReveal() {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) setVisible(true); }, { threshold: 0.1 });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return { ref, visible };
}

function RevealSection({ children, className = "", delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const { ref, visible } = useReveal();
  return (
    <div
      ref={ref}
      className={className}
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(40px)",
        transition: `opacity 700ms cubic-bezier(0.23,1,0.32,1) ${delay}ms, transform 700ms cubic-bezier(0.23,1,0.32,1) ${delay}ms`,
      }}
    >
      {children}
    </div>
  );
}

export default function Home() {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [heroVisible, setHeroVisible] = useState(false);
  const [activeTestimonial, setActiveTestimonial] = useState(0);

  useEffect(() => {
    const t = setTimeout(() => setHeroVisible(true), 100);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const handleMouseMove = (e: React.MouseEvent) => {
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    setMousePos({
      x: ((e.clientX - rect.left) / rect.width - 0.5) * 20,
      y: ((e.clientY - rect.top) / rect.height - 0.5) * 20,
    });
  };

  return (
    <div className="min-h-screen bg-[#0D0D0D] overflow-x-hidden">
      <Navbar />

      {/* ── SECTION 1: Hero ── */}
      <section
        className="relative min-h-screen flex items-center overflow-hidden"
        onMouseMove={handleMouseMove}
      >
        {/* Background image */}
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url(${HERO_BG})`,
            transform: `translate(${mousePos.x * 0.3}px, ${mousePos.y * 0.3}px) scale(1.05)`,
            transition: "transform 300ms cubic-bezier(0.23,1,0.32,1)",
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0D0D0D] via-[#0D0D0D]/80 to-[#0D0D0D]/30" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0D] via-transparent to-[#0D0D0D]/20" />

        {/* Floating mascot */}
        <div
          className="absolute right-8 bottom-12 w-48 md:w-64 lg:w-80 animate-float-delayed pointer-events-none"
          style={{ transform: `translate(${mousePos.x * -0.5}px, ${mousePos.y * -0.5}px)` }}
        >
          <img src={MASCOT} alt="Brainy the mascot" className="w-full h-full object-contain drop-shadow-2xl" />
        </div>

        {/* Hero content */}
        <div className="relative z-10 max-w-[1280px] mx-auto px-4 sm:px-6 pt-24 pb-16">
          <div className="max-w-2xl">
            {/* Stamp label */}
            <div
              className="inline-block mb-6"
              style={{
                opacity: heroVisible ? 1 : 0,
                transform: heroVisible ? "scale(1) rotate(-1deg)" : "scale(1.3) rotate(-5deg)",
                transition: "all 0.5s cubic-bezier(0.23,1,0.32,1) 0.1s",
              }}
            >
              <span className="bit-stamp text-[#FF4D1C] border-[#FF4D1C] rotate-[-1deg] inline-block">
                📢 Free. Sarcastic. Actually Useful.
              </span>
            </div>

            {/* Main headline */}
            <h1
              className="font-display font-black leading-[0.9] mb-6"
              style={{
                fontSize: "clamp(3.5rem, 8vw, 7rem)",
                opacity: heroVisible ? 1 : 0,
                transform: heroVisible ? "translateY(0)" : "translateY(50px)",
                transition: "all 0.7s cubic-bezier(0.23,1,0.32,1) 0.2s",
              }}
            >
              <span className="text-[#F5F0E8] block">BRAIN</span>
              <span className="text-[#FFD600] block">CELLS</span>
              <span className="text-[#F5F0E8] block relative">
                IN <Highlighter color="#FF4D1C">THEORY</Highlighter>
                <span className="absolute -bottom-2 left-0 right-0 h-1 bg-[#FF4D1C]" />
              </span>
            </h1>

            {/* Subheadline */}
            <p
              className="font-body text-lg md:text-xl text-[#F5F0E8]/70 mb-2 leading-relaxed"
              style={{
                opacity: heroVisible ? 1 : 0,
                transform: heroVisible ? "translateY(0)" : "translateY(30px)",
                transition: "all 0.7s cubic-bezier(0.23,1,0.32,1) 0.35s",
              }}
            >
              The study platform for students who know they're <Highlighter color="#FFD600">cooked</Highlighter>
            </p>
            <p
              className="font-serif italic text-[#FFD600] text-xl md:text-2xl mb-8"
              style={{
                opacity: heroVisible ? 1 : 0,
                transform: heroVisible ? "translateY(0)" : "translateY(30px)",
                transition: "all 0.7s cubic-bezier(0.23,1,0.32,1) 0.45s",
              }}
            >
              but show up anyway.
            </p>

            {/* CTAs */}
            <div
              className="flex flex-wrap gap-3"
              style={{
                opacity: heroVisible ? 1 : 0,
                transform: heroVisible ? "translateY(0)" : "translateY(20px)",
                transition: "all 0.7s cubic-bezier(0.23,1,0.32,1) 0.55s",
              }}
            >
              <Link
                href="/subjects"
                className="bit-btn inline-flex items-center gap-2 px-6 py-3 bg-[#FFD600] text-[#0D0D0D] font-display font-black text-sm uppercase tracking-wider rounded hover:bg-[#FFD600]/90"
              >
                Start Suffering Smarter →
              </Link>
              <Link
                href="/panic"
                className="bit-btn inline-flex items-center gap-2 px-6 py-3 bg-transparent text-[#FF4D1C] font-display font-700 text-sm uppercase tracking-wider rounded border border-[#FF4D1C] hover:bg-[#FF4D1C]/10"
              >
                🚨 Panic Mode
              </Link>
            </div>

            {/* Mini stats */}
            <div
              className="flex flex-wrap gap-6 mt-10"
              style={{
                opacity: heroVisible ? 1 : 0,
                transition: "all 0.7s cubic-bezier(0.23,1,0.32,1) 0.7s",
              }}
            >
              {stats.slice(0, 3).map((s) => (
                <div key={s.label}>
                  <div className="font-display font-black text-2xl text-[#FFD600]">{s.value}</div>
                  <div className="font-mono text-xs text-[#555] uppercase tracking-wider">{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Margin note */}
        <div className="absolute right-6 top-1/2 -translate-y-1/2 hidden xl:block">
          <MarginNote className="max-w-[120px] text-right">
            *not responsible for any grades improved or destroyed
          </MarginNote>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce">
          <span className="font-mono text-xs text-[#333] uppercase tracking-widest">scroll</span>
          <div className="w-px h-8 bg-gradient-to-b from-[#333] to-transparent" />
        </div>
      </section>

      {/* ── SECTION 2: Subjects ── */}
      <section className="py-24 relative overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-10"
          style={{ backgroundImage: `url(${SUBJECTS_BG})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0D0D0D] via-transparent to-[#0D0D0D]" />

        <div className="relative z-10 max-w-[1280px] mx-auto px-4 sm:px-6">
          <RevealSection className="mb-12">
            <div className="flex items-end justify-between">
              <div>
                <span className="bit-stamp text-[#FFD600] border-[#FFD600] mb-4 inline-block">
                  Step 1: Choose your pain
                </span>
                <h2 className="font-display font-black text-4xl md:text-6xl text-[#F5F0E8] leading-tight">
                  PICK A<br />
                  <span className="text-[#FFD600]">SUBJECT.</span>
                </h2>
                <p className="font-body text-[#555] mt-3 text-lg">
                  Or let the subject pick you. Either way, you're here now.
                </p>
              </div>
              <Link href="/subjects" className="hidden md:block font-mono text-xs text-[#333] hover:text-[#FFD600] transition-colors uppercase tracking-widest">
                View all →
              </Link>
            </div>
          </RevealSection>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {subjects.map((subject, i) => (
              <RevealSection key={subject.slug} delay={i * 80}>
                <Link href={`/subjects/${subject.slug}`}>
                  <div
                    className="bit-card-hover group relative rounded-lg border p-6 cursor-pointer overflow-hidden h-full"
                    style={{ background: subject.bg, borderColor: `${subject.color}30` }}
                  >
                    {/* Corner accent */}
                    <div
                      className="absolute top-0 right-0 w-16 h-16 opacity-20"
                      style={{ background: `radial-gradient(circle at top right, ${subject.color}, transparent)` }}
                    />

                    <div className="text-4xl mb-4">{subject.icon}</div>
                    <h3
                      className="font-display font-black text-2xl mb-2"
                      style={{ color: subject.color }}
                    >
                      {subject.name}
                    </h3>
                    <p className="font-body text-sm text-[#F5F0E8]/60 mb-4 leading-relaxed">
                      {subject.desc}
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {subject.topics.map((t) => (
                        <span
                          key={t}
                          className="font-mono text-[10px] px-2 py-0.5 rounded-full border"
                          style={{ color: subject.color, borderColor: `${subject.color}40`, background: `${subject.color}10` }}
                        >
                          {t}
                        </span>
                      ))}
                    </div>
                    <div
                      className="mt-4 font-display font-700 text-xs uppercase tracking-wider flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity"
                      style={{ color: subject.color }}
                    >
                      Enter hub →
                    </div>
                  </div>
                </Link>
              </RevealSection>
            ))}
          </div>
        </div>
      </section>

      {/* Torn edge divider */}
      <TornEdge direction="bottom" bgColor="#0D0D0D" />

      {/* Editorial break */}
      <EditorialBreak
        text='"You are not behind. You are just very ahead of being behind." — BiT, probably'
        color="#FFD600"
        className="mx-4 sm:mx-8 -mt-2 mb-0"
      />

      {/* ── SECTION 3: Features ── */}
      <section className="py-24 bg-[#080808] relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_#FFD60008_0%,_transparent_70%)]" />
        <div className="relative z-10 max-w-[1280px] mx-auto px-4 sm:px-6">
          <RevealSection className="mb-16 text-center">
            <span className="bit-stamp text-[#00E5A0] border-[#00E5A0] mb-4 inline-block">
              What's in the box
            </span>
            <h2 className="font-display font-black text-4xl md:text-6xl text-[#F5F0E8] leading-tight">
              EVERYTHING YOU<br />
              <span className="text-[#00E5A0]">DIDN'T KNOW</span><br />
              YOU NEEDED.
            </h2>
            <p className="font-body text-[#555] mt-4 text-lg max-w-xl mx-auto">
              You came for one study guide. You'll leave with a productivity system, a planner, and an existential crisis.
            </p>
          </RevealSection>

          {/* Teacher note annotation */}
          <div className="mb-8 flex justify-end">
            <TeacherNote className="max-w-xs">
              See me after class. Also: these are all real features. Shocking, we know.
            </TeacherNote>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {features.map((f, i) => (
              <RevealSection key={f.title} delay={i * 60}>
                <div
                  className="group p-5 rounded-lg border border-[#1A1A1A] bg-[#111] hover:border-current transition-all duration-300 cursor-default"
                  style={{ "--tw-border-opacity": "0.3" } as React.CSSProperties}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLElement).style.borderColor = `${f.color}50`;
                    (e.currentTarget as HTMLElement).style.background = `${f.color}08`;
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLElement).style.borderColor = "#1A1A1A";
                    (e.currentTarget as HTMLElement).style.background = "#111";
                  }}
                >
                  <div className="text-3xl mb-3 group-hover:scale-110 transition-transform duration-200 inline-block">
                    {f.icon}
                  </div>
                  <h3 className="font-display font-700 text-sm text-[#F5F0E8] mb-1">{f.title}</h3>
                  <p className="font-body text-xs text-[#555] leading-relaxed">{f.desc}</p>
                </div>
              </RevealSection>
            ))}
          </div>
        </div>
      </section>

      {/* Footnotes */}
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 pb-8 space-y-2">
        <Footnote number={1}>AI Summaries are powered by a language model that is, statistically speaking, more reliable than your memory at 2am.</Footnote>
        <Footnote number={2}>Gamification badges are not redeemable for college credits. We checked. Twice.</Footnote>
      </div>

      {/* ── SECTION 4: Stats ── */}
      <section className="py-20 border-y border-[#1A1A1A] relative overflow-hidden">
        <div className="absolute inset-0 bg-[repeating-linear-gradient(90deg,_#FFD60005_0px,_#FFD60005_1px,_transparent_1px,_transparent_80px)]" />
        <div className="relative z-10 max-w-[1280px] mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((s, i) => (
              <RevealSection key={s.label} delay={i * 100} className="text-center">
                <div className="font-display font-black text-4xl md:text-5xl text-[#FFD600] mb-2">{s.value}</div>
                <div className="font-mono text-xs text-[#555] uppercase tracking-widest leading-relaxed">{s.label}</div>
              </RevealSection>
            ))}
          </div>
        </div>
      </section>

      {/* Editorial break between stats and testimonials */}
      <EditorialBreak
        text='98% survival rate. The other 2% are fine. Probably.'
        color="#FF4D1C"
        className="mx-4 sm:mx-8 my-0"
      />

      {/* ── SECTION 5: Testimonials ── */}
      <section className="py-24 relative">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <RevealSection className="mb-12">
              <span className="bit-stamp text-[#7B61FF] border-[#7B61FF] mb-4 inline-block">
              Real students, real suffering
            </span>
            <div className="flex items-start gap-6">
              <h2 className="font-display font-black text-4xl md:text-5xl text-[#F5F0E8]">
                THEY SURVIVED.<br />
                <span className="text-[#7B61FF]">BARELY.</span>
              </h2>
              <div className="hidden md:block mt-2">
                <Stamp color="#7B61FF" rotate={3}>Verified</Stamp>
              </div>
            </div>
          </RevealSection>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {testimonials.map((t, i) => (
              <RevealSection key={t.name} delay={i * 80}>
                <div
                  className={`p-5 rounded-lg border transition-all duration-500 ${
                    activeTestimonial === i
                      ? "border-[#7B61FF]/50 bg-[#7B61FF]/10"
                      : "border-[#1A1A1A] bg-[#111]"
                  }`}
                >
                  <div className="flex gap-0.5 mb-3">
                    {Array(t.rating).fill(0).map((_, j) => (
                      <span key={j} className="text-[#FFD600] text-sm">★</span>
                    ))}
                  </div>
                  <p className="font-body text-sm text-[#F5F0E8]/80 leading-relaxed mb-4 italic">
                    "{t.text}"
                  </p>
                  <div>
                    <div className="font-display font-700 text-sm text-[#F5F0E8]">{t.name}</div>
                    <div className="font-mono text-xs text-[#555]">{t.grade}</div>
                  </div>
                </div>
              </RevealSection>
            ))}
          </div>
        </div>
      </section>

      {/* ── SECTION 6: Panic Mode CTA ── */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_#FF4D1C15_0%,_transparent_60%)]" />
        <div className="relative z-10 max-w-[1280px] mx-auto px-4 sm:px-6 text-center">
          <RevealSection>
            <span className="bit-stamp text-[#FF4D1C] border-[#FF4D1C] mb-6 inline-block animate-pulse">
              ⚠️ EXAM IN 2 HOURS?
            </span>
            <h2 className="font-display font-black text-5xl md:text-7xl text-[#F5F0E8] leading-tight mb-4">
              ACTIVATE<br />
              <span className="text-[#FF4D1C]">PANIC MODE.</span>
            </h2>
            <p className="font-body text-[#F5F0E8]/60 text-lg mb-8 max-w-lg mx-auto">
              We strip everything down to what you actually need to know. No fluff. No time for fluff. Just survival.
            </p>
            <Link
              href="/panic"
              className="bit-btn inline-flex items-center gap-3 px-8 py-4 bg-[#FF4D1C] text-white font-display font-black text-lg uppercase tracking-wider rounded hover:bg-[#FF4D1C]/80"
            >
              🚨 Enter Panic Mode
            </Link>
          </RevealSection>
        </div>
      </section>

      {/* ── SECTION 7: Final CTA ── */}
      <section className="py-24 bg-[#FFD600] relative overflow-hidden">
        <div className="absolute inset-0 bg-[repeating-linear-gradient(45deg,_#0D0D0D08_0px,_#0D0D0D08_1px,_transparent_1px,_transparent_20px)]" />
        <div className="relative z-10 max-w-[1280px] mx-auto px-4 sm:px-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            <div>
              <h2 className="font-display font-black text-4xl md:text-6xl text-[#0D0D0D] leading-tight">
                STOP SCROLLING.<br />
                START STUDYING.
              </h2>
              <p className="font-body text-[#0D0D0D]/60 text-lg mt-3">
                (We know you won't. But we had to try.)
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3 shrink-0">
              <Link
                href="/subjects"
                className="bit-btn inline-flex items-center justify-center gap-2 px-8 py-4 bg-[#0D0D0D] text-[#FFD600] font-display font-black text-sm uppercase tracking-wider rounded hover:bg-[#0D0D0D]/80"
              >
                Browse Subjects →
              </Link>
              <button
                onClick={() => toast.success("Account creation coming soon! Study now, sign up later.")}
                className="bit-btn inline-flex items-center justify-center gap-2 px-8 py-4 bg-transparent text-[#0D0D0D] font-display font-700 text-sm uppercase tracking-wider rounded border-2 border-[#0D0D0D] hover:bg-[#0D0D0D]/10"
              >
                Create Free Account
              </button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
