/* ============================================================
   BiT Panic Mode — Normal → Countdown → Simplification → Exam → Recovery
   Full dramatic experience for last-minute studying
   ============================================================ */
import { useState, useEffect, useRef } from "react";
import { Link } from "wouter";
import Navbar from "@/components/Navbar";
import { toast } from "sonner";

const PANIC_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663765059109/J3DCNwY54D46DrPmWoXEao/bit-panic-bg-PCcdsokfkcwdfustTacNzp.webp";

const panicTips = [
  "Read the chapter summaries, not the whole chapter. You're out of time.",
  "Focus on bold terms and definitions. That's what they test.",
  "Do practice problems, not more reading. Active recall > passive reading.",
  "Write down the 5 most important things you need to know. Just 5.",
  "Sleep for at least 6 hours. Seriously. Your brain consolidates memory during sleep.",
  "Don't start new topics. Master what you've already started.",
  "Eat something. Your brain runs on glucose, not anxiety.",
  "The formula sheet is your best friend. Know what's on it.",
];

const quickGuides = [
  { subject: "Math", color: "#7B61FF", title: "Quadratic Formula", content: "x = (-b ± √(b²-4ac)) / 2a", type: "formula" },
  { subject: "Science", color: "#00E5A0", title: "Newton's 2nd Law", content: "F = ma (Force = mass × acceleration)", type: "formula" },
  { subject: "History", color: "#FF4D1C", title: "WW2 Key Dates", content: "1939: War starts\n1941: Pearl Harbor\n1944: D-Day\n1945: War ends", type: "list" },
  { subject: "English", color: "#FFD600", title: "Essay Structure", content: "Intro → Thesis\nBody 1 → Evidence\nBody 2 → Evidence\nBody 3 → Evidence\nConclusion → Restate thesis", type: "list" },
  { subject: "Math", color: "#7B61FF", title: "Pythagorean Theorem", content: "a² + b² = c²\n(right triangles only)", type: "formula" },
  { subject: "Science", color: "#00E5A0", title: "Cell Types", content: "Prokaryote: no nucleus\nEukaryote: has nucleus\nAnimal: no cell wall\nPlant: has cell wall", type: "list" },
];

const loadingMessages = [
  "Calculating your chances of passing...",
  "Consulting the academic emergency protocol...",
  "Activating survival mode...",
  "Compressing 3 months of content into 2 hours...",
  "Preparing the bare minimum you need to know...",
];

export default function PanicMode() {
  const [phase, setPhase] = useState<"intro" | "active" | "recovery">("intro");
  const [hours, setHours] = useState(2);
  const [minutes, setMinutes] = useState(0);
  const [timeLeft, setTimeLeft] = useState(0);
  const [loading, setLoading] = useState(false);
  const [loadingMsg, setLoadingMsg] = useState(0);
  const [tipIndex, setTipIndex] = useState(0);
  const [shake, setShake] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (phase === "active" && timeLeft > 0) {
      intervalRef.current = setInterval(() => {
        setTimeLeft((t) => {
          if (t <= 1) {
            clearInterval(intervalRef.current!);
            setPhase("recovery");
            return 0;
          }
          return t - 1;
        });
      }, 1000);
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [phase, timeLeft]);

  useEffect(() => {
    if (phase === "active") {
      const t = setInterval(() => {
        setTipIndex((i) => (i + 1) % panicTips.length);
      }, 8000);
      return () => clearInterval(t);
    }
  }, [phase]);

  const handleActivate = () => {
    setLoading(true);
    let msg = 0;
    const t = setInterval(() => {
      msg++;
      if (msg < loadingMessages.length) {
        setLoadingMsg(msg);
      } else {
        clearInterval(t);
        setLoading(false);
        setTimeLeft((hours * 60 + minutes) * 60);
        setPhase("active");
        setShake(true);
        setTimeout(() => setShake(false), 1000);
      }
    }, 600);
  };

  const formatTime = (secs: number) => {
    const h = Math.floor(secs / 3600);
    const m = Math.floor((secs % 3600) / 60);
    const s = secs % 60;
    return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  const totalSecs = (hours * 60 + minutes) * 60;
  const pct = totalSecs > 0 ? ((totalSecs - timeLeft) / totalSecs) * 100 : 0;

  return (
    <div
      className={`min-h-screen bg-[#0D0D0D] overflow-x-hidden ${shake ? "panic-shake" : ""}`}
      style={phase === "active" ? { background: "#0D0000" } : {}}
    >
      <Navbar />

      {/* ── INTRO PHASE ── */}
      {phase === "intro" && (
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
          <div
            className="absolute inset-0 bg-cover bg-center opacity-30"
            style={{ backgroundImage: `url(${PANIC_BG})` }}
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#0D0000]/80 via-[#0D0000]/60 to-[#0D0000]" />

          <div className="relative z-10 max-w-2xl mx-auto px-4 sm:px-6 text-center pt-20">
            {loading ? (
              <div className="space-y-4">
                <div className="text-6xl animate-spin-slow">🧠</div>
                <p className="font-mono text-sm text-[#FF4D1C] animate-blink">
                  {loadingMessages[loadingMsg]}
                </p>
                <div className="w-64 mx-auto h-1 bg-[#1A0000] rounded overflow-hidden">
                  <div
                    className="h-full bg-[#FF4D1C] transition-all duration-500"
                    style={{ width: `${(loadingMsg / loadingMessages.length) * 100}%` }}
                  />
                </div>
              </div>
            ) : (
              <>
                <div className="inline-block mb-6 animate-pulse">
                  <span className="bit-stamp text-[#FF4D1C] border-[#FF4D1C] text-base">
                    ⚠️ ACADEMIC EMERGENCY PROTOCOL
                  </span>
                </div>
                <h1 className="font-display font-black text-6xl md:text-8xl text-[#FF4D1C] leading-tight mb-4">
                  PANIC<br />MODE
                </h1>
                <p className="font-body text-[#F5F0E8]/60 text-lg mb-8">
                  For when you have 2 hours until your exam and you haven't started yet.
                  We don't judge. We just help you survive.
                </p>

                {/* Time input */}
                <div className="bg-[#1A0000] border border-[#FF4D1C]/30 rounded-xl p-6 mb-8">
                  <p className="font-mono text-xs text-[#FF4D1C] uppercase tracking-widest mb-4">
                    How much time do you have?
                  </p>
                  <div className="flex items-center justify-center gap-4">
                    <div className="text-center">
                      <input
                        type="number"
                        min="0"
                        max="12"
                        value={hours}
                        onChange={(e) => setHours(Math.max(0, Math.min(12, parseInt(e.target.value) || 0)))}
                        className="w-20 text-center font-display font-black text-4xl bg-transparent text-[#FF4D1C] border-b-2 border-[#FF4D1C]/50 focus:outline-none focus:border-[#FF4D1C]"
                      />
                      <div className="font-mono text-xs text-[#555] mt-1">HOURS</div>
                    </div>
                    <span className="font-display font-black text-4xl text-[#FF4D1C]/50">:</span>
                    <div className="text-center">
                      <input
                        type="number"
                        min="0"
                        max="59"
                        value={minutes}
                        onChange={(e) => setMinutes(Math.max(0, Math.min(59, parseInt(e.target.value) || 0)))}
                        className="w-20 text-center font-display font-black text-4xl bg-transparent text-[#FF4D1C] border-b-2 border-[#FF4D1C]/50 focus:outline-none focus:border-[#FF4D1C]"
                      />
                      <div className="font-mono text-xs text-[#555] mt-1">MINUTES</div>
                    </div>
                  </div>
                </div>

                <button
                  onClick={handleActivate}
                  disabled={hours === 0 && minutes === 0}
                  className="px-10 py-4 bg-[#FF4D1C] text-white font-display font-black text-lg uppercase tracking-wider rounded hover:bg-[#FF4D1C]/80 transition-all disabled:opacity-40 animate-pulse-glow"
                >
                  🚨 ACTIVATE PANIC MODE
                </button>
                <p className="font-mono text-xs text-[#333] mt-4">
                  Warning: May cause productivity. Side effects include actually passing.
                </p>
              </>
            )}
          </div>
        </section>
      )}

      {/* ── ACTIVE PHASE ── */}
      {phase === "active" && (
        <div className="pt-16">
          {/* Countdown bar */}
          <div className="fixed top-16 left-0 right-0 z-40 bg-[#1A0000] border-b border-[#FF4D1C]/30 px-4 py-3">
            <div className="max-w-[1280px] mx-auto flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <span className="text-[#FF4D1C] animate-blink text-lg">🚨</span>
                <span className="font-mono font-700 text-2xl text-[#FF4D1C]">{formatTime(timeLeft)}</span>
                <span className="font-mono text-xs text-[#555]">remaining</span>
              </div>
              <div className="flex-1 max-w-xs">
                <div className="h-1.5 bg-[#1A0000] rounded overflow-hidden border border-[#FF4D1C]/20">
                  <div
                    className="h-full bg-[#FF4D1C] transition-all duration-1000"
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
              <button
                onClick={() => { setPhase("intro"); if (intervalRef.current) clearInterval(intervalRef.current); }}
                className="font-mono text-xs text-[#555] hover:text-[#FF4D1C] transition-colors"
              >
                Exit panic
              </button>
            </div>
          </div>

          <div className="max-w-[1280px] mx-auto px-4 sm:px-6 pt-20 pb-16">
            {/* Tip of the moment */}
            <div className="bg-[#1A0000] border border-[#FF4D1C]/30 rounded-xl p-5 mb-8 flex items-start gap-4">
              <span className="text-2xl shrink-0">💡</span>
              <div>
                <div className="font-mono text-xs text-[#FF4D1C] uppercase tracking-widest mb-1">Survival Tip</div>
                <p className="font-body text-[#F5F0E8]/80 leading-relaxed">{panicTips[tipIndex]}</p>
              </div>
            </div>

            {/* Quick reference cards */}
            <h2 className="font-display font-black text-2xl text-[#F5F0E8] mb-4">
              Quick Reference <span className="font-mono text-sm text-[#555] font-normal">— the bare minimum</span>
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
              {quickGuides.map((g, i) => (
                <div
                  key={i}
                  className="p-4 rounded-lg border bg-[#0D0000]"
                  style={{ borderColor: `${g.color}30` }}
                >
                  <div className="flex items-center gap-2 mb-2">
                    <span className="bit-stamp text-xs" style={{ color: g.color, borderColor: `${g.color}50` }}>
                      {g.subject}
                    </span>
                  </div>
                  <h3 className="font-display font-700 text-sm text-[#F5F0E8] mb-2">{g.title}</h3>
                  <pre className="font-mono text-xs leading-relaxed whitespace-pre-wrap" style={{ color: g.color }}>
                    {g.content}
                  </pre>
                </div>
              ))}
            </div>

            {/* Subject links */}
            <h2 className="font-display font-black text-2xl text-[#F5F0E8] mb-4">
              Jump to Subject <span className="font-mono text-sm text-[#555] font-normal">— pick your emergency</span>
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { name: "Math", slug: "math", color: "#7B61FF", icon: "∑" },
                { name: "Science", slug: "science", color: "#00E5A0", icon: "⚛" },
                { name: "History", slug: "history", color: "#FF4D1C", icon: "🗺" },
                { name: "English", slug: "english", color: "#FFD600", icon: "✍" },
              ].map((s) => (
                <Link
                  key={s.slug}
                  href={`/subjects/${s.slug}`}
                  className="flex items-center gap-3 p-4 rounded-lg border transition-all duration-200"
                  style={{ borderColor: `${s.color}30`, background: `${s.color}08` }}
                  onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = `${s.color}60`; }}
                  onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = `${s.color}30`; }}
                >
                  <span className="text-2xl">{s.icon}</span>
                  <span className="font-display font-700 text-sm" style={{ color: s.color }}>{s.name}</span>
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── RECOVERY PHASE ── */}
      {phase === "recovery" && (
        <section className="min-h-screen flex items-center justify-center">
          <div className="max-w-xl mx-auto px-4 text-center pt-20">
            <div className="text-8xl mb-6">🧠</div>
            <h1 className="font-display font-black text-5xl text-[#00E5A0] mb-4">
              TIME'S UP.
            </h1>
            <p className="font-body text-xl text-[#F5F0E8]/60 mb-2">
              You either know it or you don't.
            </p>
            <p className="font-serif italic text-[#555] mb-8">
              "The exam doesn't know you were up until 3am. But you do."
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <button
                onClick={() => setPhase("intro")}
                className="px-6 py-3 bg-[#00E5A0] text-[#0D0D0D] font-display font-black text-sm uppercase tracking-wider rounded hover:bg-[#00E5A0]/80 transition-all"
              >
                Go Again (Why?)
              </button>
              <Link
                href="/"
                className="px-6 py-3 border border-[#333] text-[#F5F0E8]/60 font-display font-600 text-sm uppercase tracking-wider rounded hover:text-[#FFD600] hover:border-[#FFD600]/40 transition-all"
              >
                Back to Home
              </Link>
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
