/* ============================================================
   BiT Planner — Morning → Assignments → Focus → Reflection
   ============================================================ */
import { useState, useEffect, useRef } from "react";
import { Link } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { toast } from "sonner";

type Task = { id: string; text: string; subject: string; done: boolean; priority: "high" | "medium" | "low" };

const subjectColors: Record<string, string> = {
  Math: "#7B61FF", Science: "#00E5A0", History: "#FF4D1C", English: "#FFD600", Other: "#555",
};

const motivationalMessages = [
  "You've got this. (Probably.)",
  "One task at a time. You're not a computer. Yet.",
  "Progress > perfection. Always.",
  "The assignment won't do itself. Trust me, it tried.",
  "Every task you complete is a task you don't have to do at 3am.",
];

const POMODORO_WORK = 25 * 60;
const POMODORO_BREAK = 5 * 60;

export default function Planner() {
  const [tasks, setTasks] = useState<Task[]>([
    { id: "1", text: "Read Chapter 5 - Calculus", subject: "Math", done: false, priority: "high" },
    { id: "2", text: "Write essay outline - The Great Gatsby", subject: "English", done: false, priority: "high" },
    { id: "3", text: "Review WW2 notes", subject: "History", done: true, priority: "medium" },
    { id: "4", text: "Practice 20 flashcards - Biology", subject: "Science", done: false, priority: "medium" },
    { id: "5", text: "Do practice problems - Algebra", subject: "Math", done: false, priority: "low" },
  ]);
  const [newTask, setNewTask] = useState("");
  const [newSubject, setNewSubject] = useState("Math");
  const [newPriority, setNewPriority] = useState<"high" | "medium" | "low">("medium");

  // Pomodoro
  const [pomodoroActive, setPomodoroActive] = useState(false);
  const [pomodoroTime, setPomodoroTime] = useState(POMODORO_WORK);
  const [pomodoroMode, setPomodoroMode] = useState<"work" | "break">("work");
  const [pomodoroCount, setPomodoroCount] = useState(0);
  const pomodoroRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const [msgIndex] = useState(() => Math.floor(Math.random() * motivationalMessages.length));

  useEffect(() => {
    if (pomodoroActive) {
      pomodoroRef.current = setInterval(() => {
        setPomodoroTime((t) => {
          if (t <= 1) {
            clearInterval(pomodoroRef.current!);
            setPomodoroActive(false);
            if (pomodoroMode === "work") {
              setPomodoroCount((c) => c + 1);
              setPomodoroMode("break");
              setPomodoroTime(POMODORO_BREAK);
              toast.success("Pomodoro complete! Take a 5-minute break. You earned it.");
            } else {
              setPomodoroMode("work");
              setPomodoroTime(POMODORO_WORK);
              toast.info("Break over. Back to suffering.");
            }
            return 0;
          }
          return t - 1;
        });
      }, 1000);
    }
    return () => { if (pomodoroRef.current) clearInterval(pomodoroRef.current); };
  }, [pomodoroActive, pomodoroMode]);

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60).toString().padStart(2, "0");
    const s = (secs % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
  };

  const addTask = () => {
    if (!newTask.trim()) return;
    setTasks((prev) => [...prev, {
      id: Date.now().toString(),
      text: newTask.trim(),
      subject: newSubject,
      done: false,
      priority: newPriority,
    }]);
    setNewTask("");
    toast.success("Task added. Now actually do it.");
  };

  const toggleTask = (id: string) => {
    setTasks((prev) => prev.map((t) => t.id === id ? { ...t, done: !t.done } : t));
  };

  const deleteTask = (id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  };

  const completedCount = tasks.filter((t) => t.done).length;
  const totalCount = tasks.length;
  const pct = totalCount > 0 ? (completedCount / totalCount) * 100 : 0;

  const priorityColors = { high: "#FF4D1C", medium: "#FFD600", low: "#00E5A0" };

  return (
    <div className="min-h-screen bg-[#0D0D0D]">
      <Navbar />

      {/* Header */}
      <section className="pt-28 pb-8 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_#FFD60008_0%,_transparent_60%)]" />
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <span className="bit-stamp text-[#FFD600] border-[#FFD600] mb-4 inline-block">
            Schedule your suffering
          </span>
          <h1 className="font-display font-black text-5xl md:text-6xl text-[#F5F0E8] mb-2">
            STUDY <span className="text-[#FFD600]">PLANNER</span>
          </h1>
          <p className="font-body text-[#555] text-lg italic">"{motivationalMessages[msgIndex]}"</p>
        </div>
      </section>

      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left: Tasks */}
          <div className="lg:col-span-2 space-y-4">
            {/* Progress */}
            <div className="p-5 rounded-xl border border-[#1A1A1A] bg-[#111]">
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-display font-700 text-sm text-[#F5F0E8]">Today's Progress</h2>
                <span className="font-mono text-xs text-[#555]">{completedCount}/{totalCount} tasks</span>
              </div>
              <div className="h-2 bg-[#1A1A1A] rounded overflow-hidden mb-2">
                <div
                  className="h-full bg-[#FFD600] rounded transition-all duration-500"
                  style={{ width: `${pct}%` }}
                />
              </div>
              <p className="font-mono text-xs text-[#555]">
                {pct === 100 ? "🎉 All done! Go touch grass." : `${Math.round(pct)}% complete. ${totalCount - completedCount} tasks left.`}
              </p>
            </div>

            {/* Add Task */}
            <div className="p-5 rounded-xl border border-[#1A1A1A] bg-[#111]">
              <h2 className="font-display font-700 text-sm text-[#F5F0E8] mb-3">Add Task</h2>
              <div className="flex gap-2 flex-wrap">
                <input
                  type="text"
                  value={newTask}
                  onChange={(e) => setNewTask(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && addTask()}
                  placeholder="What are you avoiding?"
                  className="flex-1 min-w-0 px-3 py-2 bg-[#0D0D0D] border border-[#333] rounded text-sm text-[#F5F0E8] placeholder-[#333] focus:outline-none focus:border-[#FFD600]/50 font-body"
                />
                <select
                  value={newSubject}
                  onChange={(e) => setNewSubject(e.target.value)}
                  className="px-3 py-2 bg-[#0D0D0D] border border-[#333] rounded text-sm text-[#F5F0E8] focus:outline-none focus:border-[#FFD600]/50 font-mono"
                >
                  {Object.keys(subjectColors).map((s) => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
                <select
                  value={newPriority}
                  onChange={(e) => setNewPriority(e.target.value as "high" | "medium" | "low")}
                  className="px-3 py-2 bg-[#0D0D0D] border border-[#333] rounded text-sm text-[#F5F0E8] focus:outline-none focus:border-[#FFD600]/50 font-mono"
                >
                  <option value="high">High</option>
                  <option value="medium">Medium</option>
                  <option value="low">Low</option>
                </select>
                <button
                  onClick={addTask}
                  className="px-4 py-2 bg-[#FFD600] text-[#0D0D0D] font-display font-700 text-sm rounded hover:bg-[#FFD600]/80 transition-all"
                >
                  Add
                </button>
              </div>
            </div>

            {/* Task List */}
            <div className="space-y-2">
              {["high", "medium", "low"].map((priority) => {
                const priorityTasks = tasks.filter((t) => t.priority === priority);
                if (priorityTasks.length === 0) return null;
                return (
                  <div key={priority}>
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-2 h-2 rounded-full" style={{ background: priorityColors[priority as keyof typeof priorityColors] }} />
                      <span className="font-mono text-xs uppercase tracking-widest" style={{ color: priorityColors[priority as keyof typeof priorityColors] }}>
                        {priority} priority
                      </span>
                    </div>
                    {priorityTasks.map((task) => (
                      <div
                        key={task.id}
                        className={`flex items-center gap-3 p-4 rounded-lg border mb-2 transition-all duration-200 ${
                          task.done ? "border-[#1A1A1A] bg-[#0D0D0D] opacity-50" : "border-[#1A1A1A] bg-[#111] hover:border-[#333]"
                        }`}
                      >
                        <button
                          onClick={() => toggleTask(task.id)}
                          className={`w-5 h-5 rounded border-2 flex items-center justify-center shrink-0 transition-all ${
                            task.done ? "bg-[#00E5A0] border-[#00E5A0]" : "border-[#333] hover:border-[#FFD600]"
                          }`}
                        >
                          {task.done && <span className="text-[#0D0D0D] text-xs font-black">✓</span>}
                        </button>
                        <div className="flex-1 min-w-0">
                          <span className={`font-body text-sm ${task.done ? "line-through text-[#555]" : "text-[#F5F0E8]"}`}>
                            {task.text}
                          </span>
                        </div>
                        <span
                          className="font-mono text-[10px] px-2 py-0.5 rounded-full shrink-0"
                          style={{
                            color: subjectColors[task.subject],
                            background: `${subjectColors[task.subject]}15`,
                          }}
                        >
                          {task.subject}
                        </span>
                        <button
                          onClick={() => deleteTask(task.id)}
                          className="text-[#333] hover:text-[#FF4D1C] transition-colors text-sm shrink-0"
                        >
                          ×
                        </button>
                      </div>
                    ))}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right: Pomodoro + Streak */}
          <div className="space-y-4">
            {/* Pomodoro Timer */}
            <div className="p-6 rounded-xl border border-[#1A1A1A] bg-[#111] text-center">
              <h2 className="font-display font-700 text-sm text-[#F5F0E8] mb-1">Pomodoro Timer</h2>
              <p className="font-mono text-xs text-[#555] mb-6">
                {pomodoroMode === "work" ? "Focus time. No excuses." : "Break time. Breathe."}
              </p>

              <div
                className="text-6xl font-display font-black mb-6 transition-colors"
                style={{ color: pomodoroMode === "work" ? "#FFD600" : "#00E5A0" }}
              >
                {formatTime(pomodoroTime)}
              </div>

              <div className="flex gap-2 justify-center mb-4">
                <button
                  onClick={() => setPomodoroActive(!pomodoroActive)}
                  className="px-5 py-2.5 rounded font-display font-700 text-sm uppercase tracking-wider transition-all"
                  style={{
                    background: pomodoroMode === "work" ? "#FFD600" : "#00E5A0",
                    color: "#0D0D0D",
                  }}
                >
                  {pomodoroActive ? "Pause" : "Start"}
                </button>
                <button
                  onClick={() => {
                    setPomodoroActive(false);
                    setPomodoroTime(POMODORO_WORK);
                    setPomodoroMode("work");
                  }}
                  className="px-5 py-2.5 rounded border border-[#333] font-display font-600 text-sm text-[#555] hover:text-[#F5F0E8] hover:border-[#555] transition-all"
                >
                  Reset
                </button>
              </div>

              <div className="flex justify-center gap-2">
                {Array(4).fill(0).map((_, i) => (
                  <div
                    key={i}
                    className="w-3 h-3 rounded-full border"
                    style={{
                      background: i < pomodoroCount % 4 ? "#FFD600" : "transparent",
                      borderColor: i < pomodoroCount % 4 ? "#FFD600" : "#333",
                    }}
                  />
                ))}
              </div>
              <p className="font-mono text-xs text-[#555] mt-2">{pomodoroCount} sessions completed</p>
            </div>

            {/* Streak */}
            <div className="p-5 rounded-xl border border-[#1A1A1A] bg-[#111]">
              <h2 className="font-display font-700 text-sm text-[#F5F0E8] mb-4">Study Streak</h2>
              <div className="text-center">
                <div className="font-display font-black text-5xl text-[#FF4D1C] mb-1">7</div>
                <div className="font-mono text-xs text-[#555]">days in a row</div>
              </div>
              <div className="grid grid-cols-7 gap-1 mt-4">
                {["M", "T", "W", "T", "F", "S", "S"].map((d, i) => (
                  <div key={i} className="text-center">
                    <div
                      className="w-full aspect-square rounded mb-1"
                      style={{ background: i < 7 ? "#FF4D1C" : "#1A1A1A" }}
                    />
                    <span className="font-mono text-[9px] text-[#555]">{d}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick links */}
            <div className="p-5 rounded-xl border border-[#1A1A1A] bg-[#111]">
              <h2 className="font-display font-700 text-sm text-[#F5F0E8] mb-3">Quick Access</h2>
              <div className="space-y-2">
                {[
                  { label: "Panic Mode", href: "/panic", color: "#FF4D1C" },
                  { label: "Flashcards", href: "/flashcards", color: "#7B61FF" },
                  { label: "Study Guides", href: "/subjects", color: "#00E5A0" },
                ].map((link) => (
                  <Link
                    key={link.href}
                    href={link.href}
                    className="flex items-center justify-between p-2.5 rounded border border-[#1A1A1A] hover:border-current transition-all text-sm font-display font-600"
                    style={{ color: link.color }}
                    onMouseEnter={(e: React.MouseEvent<HTMLAnchorElement>) => { (e.currentTarget as HTMLElement).style.borderColor = `${link.color}40`; }}
                    onMouseLeave={(e: React.MouseEvent<HTMLAnchorElement>) => { (e.currentTarget as HTMLElement).style.borderColor = "#1A1A1A"; }}
                  >
                    {link.label}
                    <span>→</span>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
