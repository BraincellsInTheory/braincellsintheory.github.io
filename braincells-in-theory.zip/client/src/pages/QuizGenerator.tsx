/* ============================================================
   BiT Quiz Generator — Test yourself before the test tests you
   ============================================================ */
import { useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { toast } from "sonner";

const sampleQuizzes: Record<string, { q: string; options: string[]; answer: number; explanation: string }[]> = {
  math: [
    { q: "What is the derivative of x²?", options: ["x", "2x", "x²", "2"], answer: 1, explanation: "Using the power rule: d/dx(xⁿ) = nxⁿ⁻¹, so d/dx(x²) = 2x." },
    { q: "Solve: 2x + 6 = 14", options: ["x = 3", "x = 4", "x = 5", "x = 10"], answer: 1, explanation: "2x = 14 - 6 = 8, so x = 4." },
    { q: "What is the area of a circle with radius 5?", options: ["25π", "10π", "5π", "50π"], answer: 0, explanation: "A = πr² = π(5²) = 25π." },
    { q: "Which is a prime number?", options: ["15", "21", "17", "9"], answer: 2, explanation: "17 is only divisible by 1 and 17. The others have additional factors." },
    { q: "What is sin(90°)?", options: ["0", "0.5", "1", "√2/2"], answer: 2, explanation: "sin(90°) = 1. This is a fundamental trigonometric value." },
  ],
  science: [
    { q: "What is the chemical formula for water?", options: ["H₂O₂", "HO", "H₂O", "H₃O"], answer: 2, explanation: "Water is H₂O — two hydrogen atoms bonded to one oxygen atom." },
    { q: "What organelle is known as the 'powerhouse of the cell'?", options: ["Nucleus", "Ribosome", "Mitochondria", "Golgi apparatus"], answer: 2, explanation: "Mitochondria produce ATP through cellular respiration." },
    { q: "Newton's 2nd Law states F = ?", options: ["mv", "ma", "mg", "m/a"], answer: 1, explanation: "Force = mass × acceleration (F = ma)." },
    { q: "What is the atomic number of Carbon?", options: ["6", "12", "8", "14"], answer: 0, explanation: "Carbon has 6 protons, giving it atomic number 6." },
    { q: "DNA stands for:", options: ["Deoxyribose Nucleic Acid", "Deoxyribonucleic Acid", "Diribonucleic Acid", "Deoxyribose Nuclear Acid"], answer: 1, explanation: "DNA = Deoxyribonucleic Acid. The 'deoxy' refers to the missing oxygen in deoxyribose sugar." },
  ],
  history: [
    { q: "In what year did WW2 end?", options: ["1943", "1944", "1945", "1946"], answer: 2, explanation: "WW2 ended in 1945 — V-E Day (May 8) and V-J Day (September 2)." },
    { q: "Who was the first US President?", options: ["John Adams", "Thomas Jefferson", "Benjamin Franklin", "George Washington"], answer: 3, explanation: "George Washington served as the first US President from 1789-1797." },
    { q: "The French Revolution began in:", options: ["1776", "1789", "1799", "1804"], answer: 1, explanation: "The French Revolution began in 1789 with the storming of the Bastille." },
    { q: "Which empire was known as the 'sick man of Europe'?", options: ["Roman Empire", "British Empire", "Ottoman Empire", "Habsburg Empire"], answer: 2, explanation: "The Ottoman Empire was called the 'sick man of Europe' in the 19th century due to its decline." },
    { q: "The Cold War was primarily between:", options: ["USA and China", "USA and USSR", "UK and USSR", "USA and Germany"], answer: 1, explanation: "The Cold War (1947-1991) was a geopolitical tension between the USA and the Soviet Union (USSR)." },
  ],
  english: [
    { q: "What literary device is 'the wind whispered'?", options: ["Metaphor", "Simile", "Personification", "Alliteration"], answer: 2, explanation: "Personification gives human qualities (whispering) to non-human things (wind)." },
    { q: "What is the theme of a story?", options: ["The main character", "The central message or lesson", "The setting", "The plot"], answer: 1, explanation: "Theme is the central message, lesson, or insight about life that the author conveys." },
    { q: "A Haiku has how many syllables?", options: ["14", "17", "10", "12"], answer: 1, explanation: "A Haiku has 17 syllables in a 5-7-5 pattern across three lines." },
    { q: "Which is an example of alliteration?", options: ["She sells sea shells", "The sun rose slowly", "Life is a dream", "He ran like the wind"], answer: 0, explanation: "'She sells sea shells' repeats the 's' sound — that's alliteration." },
    { q: "What is the protagonist?", options: ["The villain", "The main character", "The narrator", "The setting"], answer: 1, explanation: "The protagonist is the main character, usually the one the story follows most closely." },
  ],
};

export default function QuizGenerator() {
  const [subject, setSubject] = useState("math");
  const [count, setCount] = useState(5);
  const [quizStarted, setQuizStarted] = useState(false);
  const [currentQ, setCurrentQ] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [showResult, setShowResult] = useState(false);
  const [showExplanation, setShowExplanation] = useState(false);
  const [generating, setGenerating] = useState(false);

  const quiz = sampleQuizzes[subject]?.slice(0, count) || [];

  const handleGenerate = () => {
    setGenerating(true);
    setTimeout(() => {
      setGenerating(false);
      setQuizStarted(true);
      setCurrentQ(0);
      setAnswers({});
      setShowResult(false);
      setShowExplanation(false);
    }, 1500);
  };

  const handleAnswer = (optionIndex: number) => {
    if (answers[currentQ] !== undefined) return;
    setAnswers((prev) => ({ ...prev, [currentQ]: optionIndex }));
    setShowExplanation(true);
  };

  const handleNext = () => {
    if (currentQ < quiz.length - 1) {
      setCurrentQ((i) => i + 1);
      setShowExplanation(false);
    } else {
      setShowResult(true);
    }
  };

  const score = Object.entries(answers).filter(([i, a]) => quiz[parseInt(i)]?.answer === a).length;

  const subjectColors: Record<string, string> = {
    math: "#7B61FF", science: "#00E5A0", history: "#FF4D1C", english: "#FFD600",
  };
  const color = subjectColors[subject] || "#FFD600";

  return (
    <div className="min-h-screen bg-[#0D0D0D]">
      <Navbar />

      {/* Header */}
      <section className="pt-28 pb-12 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_#00E5A015_0%,_transparent_60%)]" />
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <span className="bit-stamp text-[#00E5A0] border-[#00E5A0] mb-4 inline-block">
            Test yourself first
          </span>
          <h1 className="font-display font-black text-5xl md:text-7xl text-[#F5F0E8] mb-4">
            QUIZ <span className="text-[#00E5A0]">GENERATOR</span>
          </h1>
          <p className="font-body text-xl text-[#555]">
            Practice questions. Because the exam will not be gentle.
          </p>
        </div>
      </section>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 pb-16">
        {!quizStarted ? (
          /* Setup */
          <div className="space-y-6">
            <div className="p-6 rounded-xl border border-[#1A1A1A] bg-[#111]">
              <h2 className="font-display font-700 text-lg text-[#F5F0E8] mb-6">Configure Your Quiz</h2>

              <div className="space-y-4">
                <div>
                  <label className="font-mono text-xs text-[#555] uppercase tracking-widest block mb-2">Subject</label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {Object.entries(subjectColors).map(([s, c]) => (
                      <button
                        key={s}
                        onClick={() => setSubject(s)}
                        className="py-2.5 rounded border font-display font-700 text-sm capitalize transition-all duration-200"
                        style={{
                          borderColor: subject === s ? c : "#333",
                          color: subject === s ? c : "#555",
                          background: subject === s ? `${c}15` : "transparent",
                        }}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="font-mono text-xs text-[#555] uppercase tracking-widest block mb-2">
                    Number of Questions: {count}
                  </label>
                  <input
                    type="range"
                    min="3"
                    max="5"
                    value={count}
                    onChange={(e) => setCount(parseInt(e.target.value))}
                    className="w-full accent-[#FFD600]"
                  />
                  <div className="flex justify-between font-mono text-xs text-[#333] mt-1">
                    <span>3</span><span>5</span>
                  </div>
                </div>
              </div>

              <button
                onClick={handleGenerate}
                disabled={generating}
                className="mt-6 w-full py-3 rounded font-display font-black text-sm uppercase tracking-wider transition-all disabled:opacity-60"
                style={{ background: color, color: "#0D0D0D" }}
              >
                {generating ? (
                  <span className="flex items-center justify-center gap-2">
                    <span className="inline-block w-4 h-4 border-2 border-[#0D0D0D]/30 border-t-[#0D0D0D] rounded-full animate-spin" />
                    Generating questions...
                  </span>
                ) : (
                  "Generate Quiz →"
                )}
              </button>
            </div>
          </div>
        ) : showResult ? (
          /* Results */
          <div className="text-center py-12">
            <div className="text-7xl mb-6">
              {score === quiz.length ? "🏆" : score >= quiz.length * 0.7 ? "🎉" : score >= quiz.length * 0.5 ? "😅" : "💀"}
            </div>
            <h2 className="font-display font-black text-5xl text-[#F5F0E8] mb-2">
              {score}/{quiz.length}
            </h2>
            <p className="font-body text-xl text-[#555] mb-2">
              {score === quiz.length
                ? "Perfect score. You might actually know this."
                : score >= quiz.length * 0.7
                ? "Not bad. Not great. But not bad."
                : score >= quiz.length * 0.5
                ? "You passed. Barely. Study more."
                : "Yikes. Open the study guide. Now."}
            </p>
            <div className="flex gap-3 justify-center mt-8">
              <button
                onClick={() => {
                  setQuizStarted(false);
                  setShowResult(false);
                }}
                className="px-6 py-3 bg-[#FFD600] text-[#0D0D0D] font-display font-black text-sm uppercase tracking-wider rounded hover:bg-[#FFD600]/80 transition-all"
              >
                New Quiz
              </button>
              <button
                onClick={() => {
                  setCurrentQ(0);
                  setAnswers({});
                  setShowResult(false);
                  setShowExplanation(false);
                }}
                className="px-6 py-3 border border-[#333] text-[#F5F0E8]/60 font-display font-600 text-sm uppercase tracking-wider rounded hover:text-[#FFD600] hover:border-[#FFD600]/40 transition-all"
              >
                Retry
              </button>
            </div>
          </div>
        ) : (
          /* Quiz */
          <div>
            {/* Progress */}
            <div className="flex items-center justify-between mb-4">
              <span className="font-mono text-xs text-[#555]">Question {currentQ + 1} of {quiz.length}</span>
              <span className="font-mono text-xs" style={{ color }}>
                {Object.keys(answers).length} answered
              </span>
            </div>
            <div className="h-1 bg-[#1A1A1A] rounded mb-6 overflow-hidden">
              <div
                className="h-full transition-all duration-300"
                style={{ width: `${((currentQ) / quiz.length) * 100}%`, background: color }}
              />
            </div>

            <div className="p-6 rounded-xl border border-[#1A1A1A] bg-[#111] mb-4">
              <p className="font-display font-700 text-lg text-[#F5F0E8] mb-6">
                {quiz[currentQ]?.q}
              </p>
              <div className="space-y-2">
                {quiz[currentQ]?.options.map((opt, i) => (
                  <button
                    key={i}
                    onClick={() => handleAnswer(i)}
                    className={`w-full text-left px-4 py-3 rounded border font-body text-sm transition-all duration-200 ${
                      answers[currentQ] !== undefined
                        ? i === quiz[currentQ].answer
                          ? "border-[#00E5A0] bg-[#00E5A0]/15 text-[#00E5A0]"
                          : answers[currentQ] === i
                          ? "border-[#FF4D1C] bg-[#FF4D1C]/15 text-[#FF4D1C]"
                          : "border-[#1A1A1A] text-[#555]"
                        : "border-[#1A1A1A] text-[#F5F0E8]/70 hover:border-[#333] hover:text-[#F5F0E8]"
                    }`}
                  >
                    <span className="font-mono text-xs mr-2 opacity-60">{String.fromCharCode(65 + i)}.</span>
                    {opt}
                  </button>
                ))}
              </div>
            </div>

            {showExplanation && (
              <div className="p-4 rounded-lg border border-[#FFD600]/30 bg-[#FFD600]/8 mb-4">
                <div className="font-mono text-xs text-[#FFD600] uppercase tracking-widest mb-1">Explanation</div>
                <p className="font-body text-sm text-[#F5F0E8]/80">{quiz[currentQ]?.explanation}</p>
              </div>
            )}

            {answers[currentQ] !== undefined && (
              <button
                onClick={handleNext}
                className="w-full py-3 rounded font-display font-black text-sm uppercase tracking-wider transition-all"
                style={{ background: color, color: "#0D0D0D" }}
              >
                {currentQ < quiz.length - 1 ? "Next Question →" : "See Results →"}
              </button>
            )}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
