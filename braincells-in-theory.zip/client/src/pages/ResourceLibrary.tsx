/* BiT Resource Library */
import { useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { toast } from "sonner";

const resources = [
  { title: "SAT Math Formula Sheet", type: "PDF", subject: "Math", color: "#7B61FF", size: "2.1 MB", downloads: 12400 },
  { title: "AP Chemistry Reference Tables", type: "PDF", subject: "Science", color: "#00E5A0", size: "3.4 MB", downloads: 8900 },
  { title: "WW2 Timeline Infographic", type: "Image", subject: "History", color: "#FF4D1C", size: "1.8 MB", downloads: 6700 },
  { title: "Literary Devices Cheat Sheet", type: "PDF", subject: "English", color: "#FFD600", size: "0.9 MB", downloads: 15200 },
  { title: "Calculus Derivatives Quick Reference", type: "PDF", subject: "Math", color: "#7B61FF", size: "1.2 MB", downloads: 9800 },
  { title: "Periodic Table (Annotated)", type: "Image", subject: "Science", color: "#00E5A0", size: "4.1 MB", downloads: 22100 },
  { title: "Essay Outline Template", type: "Doc", subject: "English", color: "#FFD600", size: "0.3 MB", downloads: 18600 },
  { title: "Ancient Civilizations Timeline", type: "Image", subject: "History", color: "#FF4D1C", size: "2.7 MB", downloads: 5400 },
  { title: "Algebra Cheat Sheet", type: "PDF", subject: "Math", color: "#7B61FF", size: "1.1 MB", downloads: 14300 },
  { title: "Biology Cell Diagrams", type: "Image", subject: "Science", color: "#00E5A0", size: "3.2 MB", downloads: 7800 },
  { title: "Poetry Analysis Framework", type: "PDF", subject: "English", color: "#FFD600", size: "0.8 MB", downloads: 9200 },
  { title: "Cold War Summary Notes", type: "PDF", subject: "History", color: "#FF4D1C", size: "1.6 MB", downloads: 4100 },
];

const subjects = ["All", "Math", "Science", "History", "English"];
const types = ["All", "PDF", "Image", "Doc"];

export default function ResourceLibrary() {
  const [subjectFilter, setSubjectFilter] = useState("All");
  const [typeFilter, setTypeFilter] = useState("All");
  const [search, setSearch] = useState("");

  const filtered = resources.filter((r) => {
    const matchSubject = subjectFilter === "All" || r.subject === subjectFilter;
    const matchType = typeFilter === "All" || r.type === typeFilter;
    const matchSearch = r.title.toLowerCase().includes(search.toLowerCase());
    return matchSubject && matchType && matchSearch;
  });

  const typeIcons: Record<string, string> = { PDF: "📄", Image: "🖼", Doc: "📝" };

  return (
    <div className="min-h-screen bg-[#0D0D0D]">
      <Navbar />
      <section className="pt-28 pb-12">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <span className="bit-stamp text-[#FF4D1C] border-[#FF4D1C] mb-4 inline-block">Free downloads</span>
          <h1 className="font-display font-black text-5xl md:text-7xl text-[#F5F0E8] mb-4">
            RESOURCE <span className="text-[#FF4D1C]">LIBRARY</span>
          </h1>
          <p className="font-body text-xl text-[#555]">Cheat sheets, reference guides, and templates. Legally free.</p>
        </div>
      </section>

      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 pb-16">
        {/* Filters */}
        <div className="flex flex-wrap gap-3 mb-6">
          <input
            type="text"
            placeholder="Search resources..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="flex-1 min-w-[200px] px-4 py-2 bg-[#111] border border-[#333] rounded text-sm text-[#F5F0E8] placeholder-[#333] focus:outline-none focus:border-[#FFD600]/50 font-body"
          />
          <div className="flex gap-2 flex-wrap">
            {subjects.map((s) => (
              <button
                key={s}
                onClick={() => setSubjectFilter(s)}
                className="font-mono text-xs px-3 py-1.5 rounded border transition-all"
                style={{
                  borderColor: subjectFilter === s ? "#FFD600" : "#333",
                  color: subjectFilter === s ? "#FFD600" : "#555",
                  background: subjectFilter === s ? "#FFD60015" : "transparent",
                }}
              >
                {s}
              </button>
            ))}
          </div>
          <div className="flex gap-2">
            {types.map((t) => (
              <button
                key={t}
                onClick={() => setTypeFilter(t)}
                className="font-mono text-xs px-3 py-1.5 rounded border transition-all"
                style={{
                  borderColor: typeFilter === t ? "#FF4D1C" : "#333",
                  color: typeFilter === t ? "#FF4D1C" : "#555",
                  background: typeFilter === t ? "#FF4D1C15" : "transparent",
                }}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((r) => (
            <div
              key={r.title}
              className="group p-5 rounded-xl border border-[#1A1A1A] bg-[#111] hover:border-current transition-all duration-200"
              onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = `${r.color}40`; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = "#1A1A1A"; }}
            >
              <div className="flex items-start justify-between mb-3">
                <span className="text-2xl">{typeIcons[r.type]}</span>
                <span className="bit-stamp text-[10px]" style={{ color: r.color, borderColor: `${r.color}50` }}>
                  {r.subject}
                </span>
              </div>
              <h3 className="font-display font-700 text-sm text-[#F5F0E8] mb-2">{r.title}</h3>
              <div className="flex items-center justify-between mb-4">
                <span className="font-mono text-xs text-[#555]">{r.type} · {r.size}</span>
                <span className="font-mono text-xs text-[#555]">↓ {r.downloads.toLocaleString()}</span>
              </div>
              <button
                onClick={() => toast.success(`Downloading ${r.title}...`)}
                className="w-full py-2 rounded font-display font-700 text-xs uppercase tracking-wider transition-all"
                style={{ background: r.color, color: "#0D0D0D" }}
              >
                Download Free
              </button>
            </div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-16">
            <div className="text-5xl mb-4">🔍</div>
            <p className="font-display font-700 text-lg text-[#555]">No resources found.</p>
            <p className="font-body text-sm text-[#333] mt-1">Try different filters. Or give up. We don't judge.</p>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
