/* ============================================================
   BiT Study Guide Page — Understand → Apply → Practice → Master
   ============================================================ */
import { useParams, Link } from "wouter";
import { useState, useEffect, useRef } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { toast } from "sonner";

const guideData: Record<string, {
  title: string; subject: string; subjectColor: string; time: string; difficulty: string;
  intro: string; sections: { title: string; content: string; type: "text" | "formula" | "example" | "quiz" }[];
  quiz: { q: string; options: string[]; answer: number }[];
}> = {
  "solving-quadratics": {
    title: "Solving Quadratic Equations",
    subject: "Math", subjectColor: "#7B61FF", time: "15 min", difficulty: "Medium",
    intro: "Quadratic equations. The bane of algebra students everywhere. But here's the thing — once you understand the three methods, you'll actually be able to solve them. Shocking, we know.",
    sections: [
      { type: "text", title: "What Even Is a Quadratic?", content: "A quadratic equation is any equation in the form ax² + bx + c = 0, where a ≠ 0. The 'quadratic' part comes from the Latin word for 'square.' Because of course it does." },
      { type: "formula", title: "The Quadratic Formula", content: "x = (-b ± √(b² - 4ac)) / 2a\n\nYes, you have to memorize this. No, there's no shortcut. Yes, it will be on the test." },
      { type: "example", title: "Example: Solve x² + 5x + 6 = 0", content: "Method 1 (Factoring): Factor into (x + 2)(x + 3) = 0\nSo x = -2 or x = -3\n\nMethod 2 (Quadratic Formula): a=1, b=5, c=6\nx = (-5 ± √(25-24)) / 2 = (-5 ± 1) / 2\nx = -2 or x = -3\n\nSame answer. Two methods. Pick your poison." },
      { type: "text", title: "The Discriminant: Your Crystal Ball", content: "The discriminant is b² - 4ac. It tells you how many solutions you have:\n• Positive → 2 real solutions\n• Zero → 1 real solution (a 'double root')\n• Negative → 0 real solutions (complex numbers, which is a whole other problem)" },
      { type: "quiz", title: "Quick Check", content: "Let's see if any of that stuck." },
    ],
    quiz: [
      { q: "What is the standard form of a quadratic equation?", options: ["ax + b = 0", "ax² + bx + c = 0", "ax³ + bx + c = 0", "ax² = 0"], answer: 1 },
      { q: "If the discriminant is negative, how many real solutions are there?", options: ["0", "1", "2", "3"], answer: 0 },
      { q: "Solve: x² - 4 = 0", options: ["x = 2", "x = -2", "x = ±2", "x = 4"], answer: 2 },
    ],
  },
  "ww2-overview": {
    title: "WW2 Overview: The Whole Mess",
    subject: "History", subjectColor: "#FF4D1C", time: "30 min", difficulty: "Medium",
    intro: "World War II. The largest armed conflict in human history. 70-85 million people died. The world was reshaped. And yes, it will be on your exam.",
    sections: [
      { type: "text", title: "How Did We Get Here?", content: "After WW1, the Treaty of Versailles was so harsh on Germany that it basically created the conditions for WW2. Germany was humiliated, economically destroyed, and resentful. Enter: Adolf Hitler and the Nazi Party, promising to restore German greatness. This is what happens when you don't handle peace treaties well." },
      { type: "text", title: "Key Dates You Must Know", content: "1939: Germany invades Poland. Britain and France declare war.\n1941: Japan attacks Pearl Harbor. US enters the war.\n1941: Germany invades the Soviet Union (Operation Barbarossa). Big mistake.\n1944: D-Day. Allied forces land in Normandy.\n1945: Germany surrenders (V-E Day, May 8).\n1945: Japan surrenders after atomic bombs (V-J Day, September 2)." },
      { type: "example", title: "The Major Players", content: "ALLIES: USA, UK, France, Soviet Union, China\nAXIS: Germany, Italy, Japan\n\nNote: The Soviet Union and USA were allies during WW2 but became enemies immediately after. History is awkward." },
      { type: "quiz", title: "Quick Check", content: "Did you actually read that?" },
    ],
    quiz: [
      { q: "When did Germany invade Poland?", options: ["1937", "1938", "1939", "1940"], answer: 2 },
      { q: "What event brought the USA into WW2?", options: ["D-Day", "Battle of Britain", "Pearl Harbor", "Battle of Stalingrad"], answer: 2 },
      { q: "What was V-E Day?", options: ["Victory in the East", "Victory in Europe", "Victory over Enemies", "Victory Everywhere"], answer: 1 },
    ],
  },
  "symbolism-guide": {
    title: "Symbolism Guide: Everything Means Something",
    subject: "English", subjectColor: "#FFD600", time: "18 min", difficulty: "Medium",
    intro: "Symbolism is when an author uses an object, person, or event to represent something beyond its literal meaning. The green light in Gatsby isn't just a light. The whale in Moby Dick isn't just a whale. Everything means something. You're welcome.",
    sections: [
      { type: "text", title: "What Is Symbolism?", content: "A symbol is anything that represents something beyond itself. Authors use symbols to add layers of meaning without spelling everything out (because that would be too easy)." },
      { type: "example", title: "Common Symbols You'll See", content: "🌹 Red rose = love, passion, sometimes death\n⚪ White = purity, innocence, sometimes emptiness\n🌊 Water = life, rebirth, the unconscious\n🌑 Darkness = evil, ignorance, the unknown\n🦅 Birds = freedom, the soul, transcendence\n🌿 Green = growth, envy, hope (depends on context)\n\nContext matters. A white dress at a wedding ≠ white dress in a horror movie." },
      { type: "text", title: "How to Identify Symbols", content: "1. Look for repetition — if an author mentions something multiple times, it's probably symbolic\n2. Pay attention to descriptions — overly detailed descriptions signal importance\n3. Ask 'why?' — why would the author include this detail?\n4. Consider the context — what's happening in the story when this symbol appears?" },
      { type: "quiz", title: "Quick Check", content: "Symbolism test. Don't overthink it." },
    ],
    quiz: [
      { q: "What does the color green commonly symbolize?", options: ["Death", "Purity", "Hope or envy", "Darkness"], answer: 2 },
      { q: "If an author mentions a specific object multiple times, it is likely:", options: ["A mistake", "Symbolic", "Foreshadowing only", "Irrelevant"], answer: 1 },
      { q: "Water commonly symbolizes:", options: ["Fire and destruction", "Life and rebirth", "Wealth and power", "Time passing"], answer: 1 },
    ],
  },
};

// Additional guide aliases — map SubjectHub slugs to existing guides
const guideAliases: Record<string, string> = {
  "mitosis": "symbolism-guide",
  "balancing-equations": "ww2-overview",
  "newtons-laws": "solving-quadratics",
  "ancient-rome": "ww2-overview",
  "essay-writing": "symbolism-guide",
  "algebra-basics": "solving-quadratics",
  "cell-biology": "symbolism-guide",
  "world-war-1": "ww2-overview",
  "poetry-analysis": "symbolism-guide",
  "calculus-intro": "solving-quadratics",
  "periodic-table": "ww2-overview",
  "civil-rights": "ww2-overview",
  "grammar-guide": "symbolism-guide",
};

const defaultGuide = guideData["solving-quadratics"];

export default function StudyGuide() {
  const params = useParams<{ slug: string }>();
  const resolvedSlug = params.slug ? (guideAliases[params.slug] || params.slug) : "";
  const guide = guideData[resolvedSlug] || defaultGuide;
  const [progress, setProgress] = useState(0);
  const [quizAnswers, setQuizAnswers] = useState<Record<number, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [saved, setSaved] = useState(false);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (!contentRef.current) return;
      const { top, height } = contentRef.current.getBoundingClientRect();
      const scrolled = Math.max(0, Math.min(100, ((window.innerHeight - top) / height) * 100));
      setProgress(scrolled);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleQuizSubmit = () => {
    setQuizSubmitted(true);
    const correct = guide.quiz.filter((q, i) => quizAnswers[i] === q.answer).length;
    if (correct === guide.quiz.length) {
      toast.success(`Perfect score! ${correct}/${guide.quiz.length}. You might actually know this.`);
    } else {
      toast.info(`${correct}/${guide.quiz.length} correct. Not bad. Not great. But not bad.`);
    }
  };

  return (
    <div className="min-h-screen bg-[#0D0D0D]">
      <Navbar />

      {/* Progress bar */}
      <div className="fixed top-0 left-0 right-0 z-[60] h-0.5 bg-[#111]">
        <div
          className="h-full transition-all duration-100"
          style={{ width: `${progress}%`, background: guide.subjectColor }}
        />
      </div>

      {/* Header */}
      <section
        className="pt-28 pb-12 relative"
        style={{ background: `linear-gradient(135deg, ${guide.subjectColor}12 0%, #0D0D0D 70%)` }}
      >
        <div className="max-w-3xl mx-auto px-4 sm:px-6">
          <div className="flex items-center gap-2 mb-4 text-xs font-mono text-[#555]">
            <Link href="/subjects" className="hover:text-[#FFD600] transition-colors">Subjects</Link>
            <span>/</span>
            <span style={{ color: guide.subjectColor }}>{guide.subject}</span>
            <span>/</span>
            <span className="text-[#F5F0E8]/50 truncate">{guide.title}</span>
          </div>

          <div className="flex flex-wrap items-center gap-3 mb-4">
            <span
              className="bit-stamp text-xs"
              style={{ color: guide.subjectColor, borderColor: `${guide.subjectColor}60` }}
            >
              {guide.subject}
            </span>
            <span className="font-mono text-xs text-[#555]">⏱ {guide.time}</span>
            <span className="font-mono text-xs px-2 py-0.5 rounded-full" style={{
              color: guide.difficulty === "Hard" ? "#FF4D1C" : "#FFD600",
              background: guide.difficulty === "Hard" ? "#FF4D1C15" : "#FFD60015",
            }}>
              {guide.difficulty}
            </span>
          </div>

          <h1 className="font-display font-black text-3xl md:text-5xl text-[#F5F0E8] mb-4 leading-tight">
            {guide.title}
          </h1>
          <p className="font-body text-[#F5F0E8]/60 text-lg leading-relaxed">
            {guide.intro}
          </p>

          <div className="flex gap-3 mt-6">
            <button
              onClick={() => { setSaved(!saved); toast.success(saved ? "Removed from saved." : "Saved! Now actually read it."); }}
              className="flex items-center gap-2 px-4 py-2 rounded border border-[#333] text-sm font-display font-600 text-[#F5F0E8]/60 hover:text-[#FFD600] hover:border-[#FFD600]/40 transition-all"
            >
              {saved ? "✓ Saved" : "☆ Save"}
            </button>
            <button
              onClick={() => toast.info("Share feature coming soon.")}
              className="flex items-center gap-2 px-4 py-2 rounded border border-[#333] text-sm font-display font-600 text-[#F5F0E8]/60 hover:text-[#FFD600] hover:border-[#FFD600]/40 transition-all"
            >
              ↗ Share
            </button>
          </div>
        </div>
      </section>

      {/* Content */}
      <div ref={contentRef} className="max-w-3xl mx-auto px-4 sm:px-6 py-12 space-y-10">
        {guide.sections.map((section, i) => (
          <div
            key={i}
            className="animate-slide-in-up"
            style={{ animationDelay: `${i * 100}ms`, animationFillMode: "both" }}
          >
            {section.type === "text" && (
              <div>
                <h2 className="font-display font-black text-xl text-[#F5F0E8] mb-3">{section.title}</h2>
                <p className="font-body text-[#F5F0E8]/70 leading-relaxed whitespace-pre-line">{section.content}</p>
              </div>
            )}
            {section.type === "formula" && (
              <div className="border border-[#7B61FF]/30 bg-[#7B61FF]/8 rounded-lg p-6">
                <div className="flex items-center gap-2 mb-3">
                  <span className="bit-stamp text-[#7B61FF] border-[#7B61FF]">Formula</span>
                </div>
                <h2 className="font-display font-black text-xl text-[#F5F0E8] mb-3">{section.title}</h2>
                <pre className="font-mono text-[#7B61FF] text-sm leading-relaxed whitespace-pre-wrap">{section.content}</pre>
              </div>
            )}
            {section.type === "example" && (
              <div className="border border-[#00E5A0]/30 bg-[#00E5A0]/5 rounded-lg p-6">
                <div className="flex items-center gap-2 mb-3">
                  <span className="bit-stamp text-[#00E5A0] border-[#00E5A0]">Example</span>
                </div>
                <h2 className="font-display font-black text-xl text-[#F5F0E8] mb-3">{section.title}</h2>
                <pre className="font-body text-[#F5F0E8]/70 text-sm leading-relaxed whitespace-pre-wrap">{section.content}</pre>
              </div>
            )}
            {section.type === "quiz" && (
              <div className="border border-[#FFD600]/30 bg-[#FFD600]/5 rounded-lg p-6">
                <div className="flex items-center gap-2 mb-4">
                  <span className="bit-stamp text-[#FFD600] border-[#FFD600]">Mini Quiz</span>
                </div>
                <h2 className="font-display font-black text-xl text-[#F5F0E8] mb-6">{section.title}</h2>
                <div className="space-y-6">
                  {guide.quiz.map((q, qi) => (
                    <div key={qi}>
                      <p className="font-display font-600 text-sm text-[#F5F0E8] mb-3">
                        {qi + 1}. {q.q}
                      </p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {q.options.map((opt, oi) => (
                          <button
                            key={oi}
                            onClick={() => !quizSubmitted && setQuizAnswers((prev) => ({ ...prev, [qi]: oi }))}
                            className={`text-left px-4 py-2.5 rounded border text-sm font-body transition-all duration-200 ${
                              quizSubmitted
                                ? oi === q.answer
                                  ? "border-[#00E5A0] bg-[#00E5A0]/15 text-[#00E5A0]"
                                  : quizAnswers[qi] === oi
                                  ? "border-[#FF4D1C] bg-[#FF4D1C]/15 text-[#FF4D1C]"
                                  : "border-[#1A1A1A] text-[#555]"
                                : quizAnswers[qi] === oi
                                ? "border-[#FFD600] bg-[#FFD600]/15 text-[#FFD600]"
                                : "border-[#1A1A1A] text-[#F5F0E8]/60 hover:border-[#333] hover:text-[#F5F0E8]"
                            }`}
                          >
                            {String.fromCharCode(65 + oi)}. {opt}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
                {!quizSubmitted ? (
                  <button
                    onClick={handleQuizSubmit}
                    disabled={Object.keys(quizAnswers).length < guide.quiz.length}
                    className="mt-6 px-6 py-2.5 bg-[#FFD600] text-[#0D0D0D] font-display font-black text-sm uppercase tracking-wider rounded disabled:opacity-40 hover:bg-[#FFD600]/90 transition-all"
                  >
                    Submit Answers
                  </button>
                ) : (
                  <div className="mt-4 p-3 rounded bg-[#00E5A0]/10 border border-[#00E5A0]/30">
                    <p className="font-mono text-xs text-[#00E5A0]">
                      ✓ Quiz complete. {guide.quiz.filter((q, i) => quizAnswers[i] === q.answer).length}/{guide.quiz.length} correct.
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>
        ))}

        {/* Navigation */}
        <div className="flex items-center justify-between pt-8 border-t border-[#1A1A1A]">
          <button
            onClick={() => toast.info("Previous guide coming soon.")}
            className="font-display font-600 text-sm text-[#555] hover:text-[#FFD600] transition-colors"
          >
            ← Previous Guide
          </button>
          <button
            onClick={() => toast.info("Next guide coming soon.")}
            className="font-display font-600 text-sm text-[#555] hover:text-[#FFD600] transition-colors"
          >
            Next Guide →
          </button>
        </div>
      </div>

      <Footer />
    </div>
  );
}
