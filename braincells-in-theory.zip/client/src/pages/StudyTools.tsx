/* BiT Study Tools Hub */
import { Link } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { toast } from "sonner";

const tools = [
  { icon: "📚", title: "Study Guides", desc: "Comprehensive guides for every topic. Actually written by humans.", href: "/subjects", color: "#7B61FF", available: true },
  { icon: "🃏", title: "Flashcards", desc: "Spaced repetition. Your memory's last hope.", href: "/flashcards", color: "#00E5A0", available: true },
  { icon: "📝", title: "Quiz Generator", desc: "Generate practice quizzes instantly.", href: "/quiz", color: "#FFD600", available: true },
  { icon: "📅", title: "Study Planner", desc: "Schedule your suffering in advance.", href: "/planner", color: "#FF4D1C", available: true },
  { icon: "🚨", title: "Panic Mode", desc: "Last-minute exam survival kit.", href: "/panic", color: "#FF2D55", available: true },
  { icon: "🧮", title: "Formula Vault", desc: "Every formula you need, organized.", href: "#", color: "#7B61FF", available: false },
  { icon: "🔁", title: "Spaced Repetition", desc: "Smart review scheduling.", href: "#", color: "#00E5A0", available: false },
  { icon: "✏️", title: "Note Taking", desc: "Take and organize notes.", href: "#", color: "#FFD600", available: false },
  { icon: "🎯", title: "Focus Mode", desc: "Block distractions. Actually study.", href: "#", color: "#FF4D1C", available: false },
  { icon: "📊", title: "Progress Tracker", desc: "See how far you've come.", href: "#", color: "#7B61FF", available: false },
  { icon: "🤖", title: "AI Summaries", desc: "Let AI explain what your teacher couldn't.", href: "#", color: "#00E5A0", available: false },
  { icon: "📖", title: "Offline Save", desc: "Study without internet. Shocking.", href: "#", color: "#FFD600", available: false },
];

export default function StudyTools() {
  return (
    <div className="min-h-screen bg-[#0D0D0D]">
      <Navbar />
      <section className="pt-28 pb-12">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <span className="bit-stamp text-[#7B61FF] border-[#7B61FF] mb-4 inline-block">Everything you need</span>
          <h1 className="font-display font-black text-5xl md:text-7xl text-[#F5F0E8] mb-4">
            STUDY <span className="text-[#7B61FF]">TOOLS</span>
          </h1>
          <p className="font-body text-xl text-[#555]">All the tools. Some of them work. All of them are free.</p>
        </div>
      </section>
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 pb-16">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {tools.map((tool) => (
            tool.available ? (
              <Link
                key={tool.title}
                href={tool.href}
                className="group p-5 rounded-xl border border-[#1A1A1A] bg-[#111] hover:border-current transition-all duration-200"
                onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = `${tool.color}40`; }}
                onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = "#1A1A1A"; }}
              >
                <div className="text-3xl mb-3">{tool.icon}</div>
                <h3 className="font-display font-700 text-sm text-[#F5F0E8] mb-1">{tool.title}</h3>
                <p className="font-body text-xs text-[#555]">{tool.desc}</p>
                <div className="mt-3 font-mono text-[10px] text-[#00E5A0]">Available →</div>
              </Link>
            ) : (
              <div
                key={tool.title}
                className="p-5 rounded-xl border border-[#1A1A1A] bg-[#0D0D0D] opacity-50 cursor-not-allowed"
                onClick={() => toast.info(`${tool.title} coming soon!`)}
              >
                <div className="text-3xl mb-3 grayscale">{tool.icon}</div>
                <h3 className="font-display font-700 text-sm text-[#555] mb-1">{tool.title}</h3>
                <p className="font-body text-xs text-[#333]">{tool.desc}</p>
                <div className="mt-3 font-mono text-[10px] text-[#333]">Coming soon</div>
              </div>
            )
          ))}
        </div>
      </div>
      <Footer />
    </div>
  );
}
