/* ============================================================
   BiT Subject Hub — Dynamic page for /subjects/[subject]
   Scrollytelling: Hero → Dashboard → Study Guide → Practice → Articles → Community → Achievements
   ============================================================ */
import { useParams, Link } from "wouter";
import { useState, useEffect } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { toast } from "sonner";

const SUBJECTS_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663765059109/J3DCNwY54D46DrPmWoXEao/bit-subjects-bg-hxPW6iWNEGa8CN6t8YjAVk.webp";

const subjectData: Record<string, {
  name: string; color: string; icon: string; tagline: string; sarcasm: string;
  topics: { name: string; slug: string; desc: string; difficulty: string }[];
  guides: { title: string; slug: string; time: string; difficulty: string }[];
  articles: { title: string; slug: string; time: string }[];
  achievements: { icon: string; name: string; desc: string }[];
}> = {
  math: {
    name: "Mathematics", color: "#7B61FF", icon: "∑",
    tagline: "Where numbers go to ruin your day.",
    sarcasm: "Allegedly useful in real life. Evidence pending.",
    topics: [
      { name: "Algebra", slug: "algebra", desc: "Solving for x. Always x.", difficulty: "Medium" },
      { name: "Geometry", slug: "geometry", desc: "Shapes and their feelings.", difficulty: "Medium" },
      { name: "Trigonometry", slug: "trig", desc: "The holy trinity of confusion.", difficulty: "Hard" },
      { name: "Calculus", slug: "calculus", desc: "The final boss.", difficulty: "Very Hard" },
      { name: "Statistics", slug: "statistics", desc: "Lying with numbers, professionally.", difficulty: "Medium" },
    ],
    guides: [
      { title: "Solving Quadratic Equations", slug: "solving-quadratics", time: "15 min", difficulty: "Medium" },
      { title: "The Pythagorean Theorem (Again)", slug: "pythagorean", time: "10 min", difficulty: "Easy" },
      { title: "Derivatives: A Survival Guide", slug: "derivatives", time: "25 min", difficulty: "Hard" },
      { title: "Probability: Why You're Unlucky", slug: "probability", time: "20 min", difficulty: "Medium" },
    ],
    articles: [
      { title: "Ranking Math Topics by How Much They Hurt", slug: "ranking-math-pain", time: "5 min" },
      { title: "Why Calculus Exists (And Who to Blame)", slug: "why-calculus", time: "7 min" },
    ],
    achievements: [
      { icon: "🔢", name: "Number Cruncher", desc: "Completed 10 math guides" },
      { icon: "📐", name: "Angle Grinder", desc: "Mastered geometry basics" },
      { icon: "∞", name: "Limit Pusher", desc: "Survived calculus intro" },
    ],
  },
  science: {
    name: "Science", color: "#00E5A0", icon: "⚛",
    tagline: "Everything is atoms. Including your excuses.",
    sarcasm: "The universe is 13.8 billion years old. Your exam is in 3 days.",
    topics: [
      { name: "Biology", slug: "biology", desc: "You are mostly water.", difficulty: "Medium" },
      { name: "Chemistry", slug: "chemistry", desc: "Balancing equations and mental health.", difficulty: "Hard" },
      { name: "Physics", slug: "physics", desc: "Newton's revenge.", difficulty: "Very Hard" },
    ],
    guides: [
      { title: "Cell Division: The Mitosis Saga", slug: "mitosis", time: "20 min", difficulty: "Medium" },
      { title: "Balancing Chemical Equations", slug: "balancing-equations", time: "18 min", difficulty: "Hard" },
      { title: "Newton's Laws of Motion (All 3)", slug: "newtons-laws", time: "22 min", difficulty: "Medium" },
      { title: "DNA Replication: Copy-Paste but Biological", slug: "dna-replication", time: "25 min", difficulty: "Hard" },
    ],
    articles: [
      { title: "Chemistry vs. Your GPA: A Love Story", slug: "chemistry-gpa", time: "6 min" },
      { title: "Biology: The Subject That Thinks It's Everything", slug: "bio-everything", time: "5 min" },
    ],
    achievements: [
      { icon: "🧬", name: "DNA Decoder", desc: "Completed 5 biology guides" },
      { icon: "⚗️", name: "Lab Rat", desc: "Mastered chemistry basics" },
      { icon: "🚀", name: "Force Field", desc: "Survived physics intro" },
    ],
  },
  history: {
    name: "History", color: "#FF4D1C", icon: "🗺",
    tagline: "Everything that went wrong, in order.",
    sarcasm: "Those who don't study history are doomed to fail the exam.",
    topics: [
      { name: "World Wars", slug: "world-war", desc: "Two of them. Both bad.", difficulty: "Medium" },
      { name: "Ancient History", slug: "ancient", desc: "Before your problems existed.", difficulty: "Easy" },
      { name: "Revolutions", slug: "revolutions", desc: "When people got really tired.", difficulty: "Medium" },
    ],
    guides: [
      { title: "WW2 Overview: The Whole Mess", slug: "ww2-overview", time: "30 min", difficulty: "Medium" },
      { title: "Ancient Rome: Rise and Obvious Fall", slug: "ancient-rome", time: "25 min", difficulty: "Easy" },
      { title: "The French Revolution: Chaos Edition", slug: "french-revolution", time: "20 min", difficulty: "Medium" },
      { title: "Cold War: Two Countries, One Anxiety", slug: "cold-war", time: "22 min", difficulty: "Medium" },
    ],
    articles: [
      { title: "Ranking Historical Events by How Avoidable They Were", slug: "ranking-history", time: "8 min" },
      { title: "Ancient Civilizations Tier List", slug: "civ-tier-list", time: "6 min" },
    ],
    achievements: [
      { icon: "🏛️", name: "Ancient Scholar", desc: "Completed 5 ancient history guides" },
      { icon: "⚔️", name: "War Historian", desc: "Mastered world war content" },
      { icon: "🔥", name: "Revolutionary", desc: "Survived revolutions module" },
    ],
  },
  english: {
    name: "English", color: "#FFD600", icon: "✍",
    tagline: "Symbolism you didn't ask for.",
    sarcasm: "The curtains were blue. The author was depressed. You will be too.",
    topics: [
      { name: "Literature", slug: "books", desc: "Dead authors, alive in your exam.", difficulty: "Medium" },
      { name: "Poetry", slug: "poetry", desc: "Feelings, but compressed.", difficulty: "Hard" },
      { name: "Writing", slug: "writing", desc: "Essays that sound smart.", difficulty: "Medium" },
    ],
    guides: [
      { title: "Symbolism Guide: Everything Means Something", slug: "symbolism-guide", time: "18 min", difficulty: "Medium" },
      { title: "Essay Writing: The 5-Paragraph Survival Kit", slug: "essay-writing", time: "20 min", difficulty: "Easy" },
      { title: "Poetry Analysis: Reading Between the Lines", slug: "poetry-analysis", time: "22 min", difficulty: "Hard" },
      { title: "Literary Devices Cheat Sheet", slug: "literary-devices", time: "15 min", difficulty: "Medium" },
    ],
    articles: [
      { title: "Every Book You'll Read in High School, Ranked by Trauma", slug: "books-ranked", time: "7 min" },
      { title: "How to Write an Essay When You Have Nothing to Say", slug: "essay-nothing", time: "5 min" },
    ],
    achievements: [
      { icon: "📖", name: "Bookworm", desc: "Completed 5 literature guides" },
      { icon: "🖊️", name: "Wordsmith", desc: "Mastered essay writing" },
      { icon: "🎭", name: "Drama Analyst", desc: "Survived poetry module" },
    ],
  },
};

function useReveal() {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 100);
    return () => clearTimeout(t);
  }, []);
  return visible;
}

const difficultyColors: Record<string, string> = {
  Easy: "#00E5A0", Medium: "#FFD600", Hard: "#FF4D1C", "Very Hard": "#FF2D55",
};

export default function SubjectHub() {
  const params = useParams<{ subject: string }>();
  const subject = subjectData[params.subject || "math"] || subjectData.math;
  const heroVisible = useReveal();

  return (
    <div className="min-h-screen bg-[#0D0D0D]">
      <Navbar />

      {/* Hero */}
      <section
        className="relative pt-28 pb-16 overflow-hidden"
        style={{ background: `linear-gradient(135deg, ${subject.color}15 0%, #0D0D0D 60%)` }}
      >
        <div className="absolute top-0 right-0 w-96 h-96 rounded-full blur-3xl opacity-10" style={{ background: subject.color }} />

        <div className="relative z-10 max-w-[1280px] mx-auto px-4 sm:px-6">
          <div
            style={{
              opacity: heroVisible ? 1 : 0,
              transform: heroVisible ? "translateY(0)" : "translateY(30px)",
              transition: "all 0.7s cubic-bezier(0.23,1,0.32,1)",
            }}
          >
            <div className="flex items-center gap-2 mb-4">
              <Link href="/subjects" className="font-mono text-xs text-[#555] hover:text-[#FFD600] transition-colors">
                Subjects
              </Link>
              <span className="text-[#333]">/</span>
              <span className="font-mono text-xs" style={{ color: subject.color }}>{subject.name}</span>
            </div>

            <div className="flex items-start gap-6">
              <span className="text-7xl">{subject.icon}</span>
              <div>
                <h1
                  className="font-display font-black text-5xl md:text-7xl leading-tight"
                  style={{ color: subject.color }}
                >
                  {subject.name.toUpperCase()}
                </h1>
                <p className="font-body text-lg text-[#F5F0E8]/60 mt-2">{subject.tagline}</p>
                <p className="font-serif italic text-[#555] text-sm mt-1">"{subject.sarcasm}"</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Topics */}
      <section className="py-16">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <h2 className="font-display font-black text-2xl text-[#F5F0E8] mb-6">
            Topics <span className="font-mono text-sm text-[#555] font-normal">— pick your poison</span>
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
            {subject.topics.map((topic, i) => (
              <Link
                key={topic.slug}
                href={`/subjects/${params.subject}/${topic.slug}`}
                className="group p-4 rounded-lg border border-[#1A1A1A] bg-[#111] hover:border-current transition-all duration-200"
                style={{
                  animation: `slide-in-up 0.5s cubic-bezier(0.23,1,0.32,1) ${i * 80}ms both`,
                }}
                onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = `${subject.color}40`; }}
                onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = "#1A1A1A"; }}
              >
                <div className="font-display font-700 text-sm text-[#F5F0E8] mb-1">{topic.name}</div>
                <div className="font-body text-xs text-[#555] mb-3">{topic.desc}</div>
                <span
                  className="font-mono text-[10px] px-2 py-0.5 rounded-full"
                  style={{ color: difficultyColors[topic.difficulty], background: `${difficultyColors[topic.difficulty]}15` }}
                >
                  {topic.difficulty}
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Study Guides */}
      <section className="py-16 bg-[#080808]">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-display font-black text-2xl text-[#F5F0E8]">
              Study Guides <span className="font-mono text-sm text-[#555] font-normal">— actually read these</span>
            </h2>
            <button
              onClick={() => toast.info("More guides coming soon.")}
              className="font-mono text-xs text-[#555] hover:text-[#FFD600] transition-colors"
            >
              View all →
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {subject.guides.map((guide, i) => (
              <Link
                key={guide.slug}
                href={`/guides/${guide.slug}`}
                className="group flex items-center justify-between p-5 rounded-lg border border-[#1A1A1A] bg-[#111] hover:bg-[#1A1A1A] transition-all duration-200"
                style={{ animation: `slide-in-up 0.5s cubic-bezier(0.23,1,0.32,1) ${i * 80}ms both` }}
                onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = `${subject.color}30`; }}
                onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = "#1A1A1A"; }}
              >
                <div>
                  <div className="font-display font-600 text-sm text-[#F5F0E8] mb-1 group-hover:text-white transition-colors">
                    {guide.title}
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-xs text-[#555]">⏱ {guide.time}</span>
                    <span
                      className="font-mono text-[10px] px-2 py-0.5 rounded-full"
                      style={{ color: difficultyColors[guide.difficulty], background: `${difficultyColors[guide.difficulty]}15` }}
                    >
                      {guide.difficulty}
                    </span>
                  </div>
                </div>
                <span className="text-[#333] group-hover:text-current transition-colors" style={{ color: subject.color }}>→</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Articles + Achievements */}
      <section className="py-16">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Articles */}
            <div>
              <h2 className="font-display font-black text-2xl text-[#F5F0E8] mb-6">
                Blog Articles <span className="font-mono text-sm text-[#555] font-normal">— procrastinate productively</span>
              </h2>
              <div className="space-y-3">
                {subject.articles.map((article) => (
                  <Link
                    key={article.slug}
                    href={`/blog/${article.slug}`}
                    className="group flex items-center justify-between p-4 rounded-lg border border-[#1A1A1A] bg-[#111] hover:border-[#FFD600]/30 transition-all duration-200"
                  >
                    <div>
                      <div className="font-display font-600 text-sm text-[#F5F0E8] group-hover:text-[#FFD600] transition-colors">
                        {article.title}
                      </div>
                      <div className="font-mono text-xs text-[#555] mt-0.5">⏱ {article.time} read</div>
                    </div>
                    <span className="text-[#333] group-hover:text-[#FFD600] transition-colors">→</span>
                  </Link>
                ))}
              </div>
            </div>

            {/* Achievements */}
            <div>
              <h2 className="font-display font-black text-2xl text-[#F5F0E8] mb-6">
                Achievements <span className="font-mono text-sm text-[#555] font-normal">— cope mechanisms</span>
              </h2>
              <div className="space-y-3">
                {subject.achievements.map((ach) => (
                  <div
                    key={ach.name}
                    className="flex items-center gap-4 p-4 rounded-lg border border-[#1A1A1A] bg-[#111]"
                  >
                    <span className="text-3xl">{ach.icon}</span>
                    <div>
                      <div className="font-display font-700 text-sm" style={{ color: subject.color }}>{ach.name}</div>
                      <div className="font-body text-xs text-[#555]">{ach.desc}</div>
                    </div>
                    <div className="ml-auto">
                      <div className="w-8 h-8 rounded-full border border-[#333] flex items-center justify-center">
                        <span className="text-[#333] text-xs">🔒</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 border-t border-[#1A1A1A]">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 text-center">
          <h3 className="font-display font-black text-3xl text-[#F5F0E8] mb-4">
            Ready to actually learn {subject.name}?
          </h3>
          <p className="font-body text-[#555] mb-6">Or at least pretend to. We support both.</p>
          <Link
            href={`/subjects/${params.subject}/${subject.topics[0]?.slug}`}
            className="inline-flex items-center gap-2 px-6 py-3 font-display font-black text-sm uppercase tracking-wider rounded"
            style={{ background: subject.color, color: "#0D0D0D" }}
          >
            Start with {subject.topics[0]?.name} →
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}
