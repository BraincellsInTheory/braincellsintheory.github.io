/* ============================================================
   BiT Subjects Page — Overwhelm → Choose → Descend into learning
   ============================================================ */
import { useState, useEffect } from "react";
import { Link } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Highlighter, MarginNote, Stamp, TeacherNote, EditorialBreak, TornEdge } from "@/components/TextbookVandalism";

const SUBJECTS_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663765059109/J3DCNwY54D46DrPmWoXEao/bit-subjects-bg-hxPW6iWNEGa8CN6t8YjAVk.webp";

const subjects = [
  {
    name: "Mathematics",
    slug: "math",
    color: "#7B61FF",
    bg: "#7B61FF",
    icon: "∑",
    tagline: "Where numbers go to ruin your day.",
    sarcasm: "Allegedly useful in real life. We're still waiting for proof.",
    topics: [
      { name: "Algebra", slug: "algebra", desc: "Solving for x since you were 13.", guides: 24 },
      { name: "Geometry", slug: "geometry", desc: "Shapes. Angles. Suffering.", guides: 18 },
      { name: "Trigonometry", slug: "trig", desc: "Sin, cos, tan — the holy trinity of confusion.", guides: 15 },
      { name: "Calculus", slug: "calculus", desc: "The final boss of high school math.", guides: 32 },
      { name: "Statistics", slug: "statistics", desc: "Lying with numbers, professionally.", guides: 20 },
    ],
    stats: { guides: 109, flashcards: 850, students: "45K" },
  },
  {
    name: "Science",
    slug: "science",
    color: "#00E5A0",
    bg: "#00E5A0",
    icon: "⚛",
    tagline: "Everything is atoms. Including your excuses.",
    sarcasm: "The universe is 13.8 billion years old. Your exam is in 3 days.",
    topics: [
      { name: "Biology", slug: "biology", desc: "You are mostly water. Act like it.", guides: 28 },
      { name: "Chemistry", slug: "chemistry", desc: "Balancing equations and mental health.", guides: 22 },
      { name: "Physics", slug: "physics", desc: "Newton invented calculus to do physics. You're welcome.", guides: 26 },
    ],
    stats: { guides: 76, flashcards: 620, students: "38K" },
  },
  {
    name: "History",
    slug: "history",
    color: "#FF4D1C",
    bg: "#FF4D1C",
    icon: "🗺",
    tagline: "Everything that went wrong, in order.",
    sarcasm: "Those who don't study history are doomed to fail the exam.",
    topics: [
      { name: "World Wars", slug: "world-war", desc: "Two of them. Both bad.", guides: 20 },
      { name: "Ancient History", slug: "ancient", desc: "Before your problems existed.", guides: 16 },
      { name: "Revolutions", slug: "revolutions", desc: "When people got really tired of things.", guides: 14 },
    ],
    stats: { guides: 50, flashcards: 480, students: "29K" },
  },
  {
    name: "English",
    slug: "english",
    color: "#FFD600",
    bg: "#FFD600",
    icon: "✍",
    tagline: "Symbolism you didn't ask for.",
    sarcasm: "The curtains were blue. The author was depressed. You will be too.",
    topics: [
      { name: "Literature", slug: "books", desc: "Dead authors, alive in your exam.", guides: 22 },
      { name: "Poetry", slug: "poetry", desc: "Feelings, but compressed and confusing.", guides: 12 },
      { name: "Writing", slug: "writing", desc: "Essays that sound smart even when you're not.", guides: 18 },
    ],
    stats: { guides: 52, flashcards: 390, students: "33K" },
  },
];

function useReveal(delay = 0) {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setVisible(true), delay);
    return () => clearTimeout(t);
  }, [delay]);
  return visible;
}

export default function Subjects() {
  const [hoveredSubject, setHoveredSubject] = useState<string | null>(null);
  const heroVisible = useReveal(100);

  return (
    <div className="min-h-screen bg-[#0D0D0D]">
      <Navbar />

      {/* Hero */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-15"
          style={{ backgroundImage: `url(${SUBJECTS_BG})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0D0D0D]/50 via-transparent to-[#0D0D0D]" />

        <div className="relative z-10 max-w-[1280px] mx-auto px-4 sm:px-6">
          <div
            style={{
              opacity: heroVisible ? 1 : 0,
              transform: heroVisible ? "translateY(0)" : "translateY(40px)",
              transition: "all 0.7s cubic-bezier(0.23,1,0.32,1)",
            }}
          >
            <span className="bit-stamp text-[#FFD600] border-[#FFD600] mb-6 inline-block">
              Choose your suffering
            </span>
            <div className="flex items-start gap-6">
              <h1 className="font-display font-black text-5xl md:text-8xl text-[#F5F0E8] leading-tight mb-4">
                ALL THE<br />
                <span className="text-[#FFD600]">SUBJECTS.</span>
              </h1>
              <div className="hidden md:block mt-4">
                <Stamp color="#FF4D1C" rotate={-3}>Required</Stamp>
              </div>
            </div>
            <p className="font-body text-xl text-[#555] max-w-xl">
              Pick one. Or all of them. We won't judge. <Highlighter color="#FF4D1C">(We will judge.)</Highlighter>
            </p>
          </div>
        </div>
      </section>

      {/* Subject Cards */}
      <section className="pb-24">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 space-y-6">
          {subjects.map((subject, i) => (
            <div
              key={subject.slug}
              className="group rounded-xl border overflow-hidden transition-all duration-500"
              style={{
                borderColor: hoveredSubject === subject.slug ? `${subject.color}50` : "#1A1A1A",
                background: hoveredSubject === subject.slug ? `${subject.color}08` : "#111",
                opacity: 1,
                transform: "translateY(0)",
                animation: `slide-in-up 0.6s cubic-bezier(0.23,1,0.32,1) ${i * 120}ms both`,
              }}
              onMouseEnter={() => setHoveredSubject(subject.slug)}
              onMouseLeave={() => setHoveredSubject(null)}
            >
              <div className="p-6 md:p-8">
                <div className="flex flex-col md:flex-row md:items-start gap-6">
                  {/* Left: Subject info */}
                  <div className="flex-1">
                    <div className="flex items-center gap-4 mb-3">
                      <span className="text-5xl">{subject.icon}</span>
                      <div>
                        <h2
                          className="font-display font-black text-3xl md:text-4xl"
                          style={{ color: subject.color }}
                        >
                          {subject.name}
                        </h2>
                        <p className="font-body text-sm text-[#555]">{subject.tagline}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 mb-4">
                      <p className="font-serif italic text-[#F5F0E8]/50 text-sm">
                        "{subject.sarcasm}"
                      </p>
                      <MarginNote className="hidden lg:block shrink-0 max-w-[100px]">see also: your grades</MarginNote>
                    </div>

                    {/* Stats */}
                    <div className="flex gap-6 mb-4">
                      {[
                        { label: "Guides", value: subject.stats.guides },
                        { label: "Flashcards", value: subject.stats.flashcards },
                        { label: "Students", value: subject.stats.students },
                      ].map((s) => (
                        <div key={s.label}>
                          <div className="font-display font-black text-xl" style={{ color: subject.color }}>
                            {s.value}
                          </div>
                          <div className="font-mono text-[10px] text-[#555] uppercase tracking-wider">{s.label}</div>
                        </div>
                      ))}
                    </div>

                    <Link
                      href={`/subjects/${subject.slug}`}
                      className="inline-flex items-center gap-2 px-5 py-2.5 font-display font-700 text-sm uppercase tracking-wider rounded transition-all duration-200"
                      style={{
                        background: subject.color,
                        color: subject.slug === "english" ? "#0D0D0D" : "#0D0D0D",
                      }}
                    >
                      Enter {subject.name} Hub →
                    </Link>
                  </div>

                  {/* Right: Topics */}
                  <div className="md:w-80 shrink-0">
                    <h4 className="font-mono text-xs text-[#555] uppercase tracking-widest mb-3">Topics</h4>
                    <div className="space-y-2">
                      {subject.topics.map((topic) => (
                        <Link
                          key={topic.slug}
                          href={`/subjects/${subject.slug}/${topic.slug}`}
                          className="flex items-center justify-between p-3 rounded bg-[#0D0D0D] border border-[#1A1A1A] hover:border-current transition-all duration-200 group/topic"
                          style={{ "--tw-border-opacity": "0.3" } as React.CSSProperties}
                          onMouseEnter={(e) => {
                            (e.currentTarget as HTMLElement).style.borderColor = `${subject.color}40`;
                          }}
                          onMouseLeave={(e) => {
                            (e.currentTarget as HTMLElement).style.borderColor = "#1A1A1A";
                          }}
                        >
                          <div>
                            <div className="font-display font-600 text-sm text-[#F5F0E8]">{topic.name}</div>
                            <div className="font-body text-xs text-[#555]">{topic.desc}</div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-xs text-[#333]">{topic.guides} guides</span>
                            <span className="text-[#333] group-hover/topic:text-current transition-colors" style={{ color: subject.color }}>→</span>
                          </div>
                        </Link>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Editorial break */}
      <EditorialBreak
        text='"The curriculum is not your enemy. Your procrastination is." — Every teacher ever'
        color="#00E5A0"
        className="mx-4 sm:mx-8 mb-12"
      />

      <Footer />
    </div>
  );
}
