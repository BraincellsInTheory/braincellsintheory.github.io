/* BiT Team Page */
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Link } from "wouter";

const team = [
  { name: "Alex Chen", role: "Co-Founder & CEO", bio: "Failed calculus twice. Built BiT out of spite. Now passes calculus.", emoji: "🧮", subject: "Math" },
  { name: "Sam Rivera", role: "Co-Founder & CTO", bio: "Computer science student who learned to code to avoid studying. The irony is not lost.", emoji: "💻", subject: "CS" },
  { name: "Jordan Park", role: "Co-Founder & Head of Content", bio: "English major. Wrote the sarcastic copy. Regrets nothing.", emoji: "✍️", subject: "English" },
  { name: "Riley Thompson", role: "Lead Designer", bio: "Made everything look like this. Intentionally.", emoji: "🎨", subject: "Art" },
  { name: "Casey Williams", role: "Community Manager", bio: "Manages 500,000 panicking students daily. Somehow still sane.", emoji: "👥", subject: "Psychology" },
  { name: "Morgan Lee", role: "Content Writer", bio: "Writes study guides and sarcastic blog posts. Sometimes both at once.", emoji: "📝", subject: "History" },
];

const openRoles = [
  { title: "Frontend Developer", type: "Volunteer", desc: "Help us build features. React + TypeScript." },
  { title: "Content Writer", type: "Volunteer", desc: "Write study guides. Must be able to explain things sarcastically." },
  { title: "Subject Expert", type: "Volunteer", desc: "Know a subject really well? Prove it." },
  { title: "Community Moderator", type: "Volunteer", desc: "Keep the community from descending into chaos." },
];

export default function Team() {
  return (
    <div className="min-h-screen bg-[#0D0D0D]">
      <Navbar />
      <section className="pt-28 pb-12">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <span className="bit-stamp text-[#7B61FF] border-[#7B61FF] mb-4 inline-block">The people responsible</span>
          <h1 className="font-display font-black text-5xl md:text-7xl text-[#F5F0E8] mb-4">
            THE <span className="text-[#7B61FF]">TEAM</span>
          </h1>
          <p className="font-body text-xl text-[#555]">Six students who refused to pay for study apps.</p>
        </div>
      </section>

      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 pb-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-16">
          {team.map((member) => (
            <div key={member.name} className="p-6 rounded-xl border border-[#1A1A1A] bg-[#111] hover:border-[#7B61FF]/30 transition-all">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-14 h-14 rounded-full bg-[#1A1A1A] flex items-center justify-center text-3xl border border-[#333]">
                  {member.emoji}
                </div>
                <div>
                  <h3 className="font-display font-700 text-base text-[#F5F0E8]">{member.name}</h3>
                  <p className="font-mono text-xs text-[#7B61FF]">{member.role}</p>
                </div>
              </div>
              <p className="font-body text-sm text-[#555] italic">"{member.bio}"</p>
              <div className="mt-3">
                <span className="font-mono text-[10px] text-[#333] uppercase tracking-widest">Expertise: {member.subject}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Open roles */}
        <div>
          <h2 className="font-display font-black text-3xl text-[#F5F0E8] mb-2">Join the Team</h2>
          <p className="font-body text-[#555] mb-6">We're a nonprofit. We pay in gratitude and sarcasm.</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {openRoles.map((role) => (
              <div key={role.title} className="p-5 rounded-xl border border-[#1A1A1A] bg-[#111] flex items-start justify-between gap-4">
                <div>
                  <h3 className="font-display font-700 text-sm text-[#F5F0E8] mb-1">{role.title}</h3>
                  <p className="font-body text-xs text-[#555]">{role.desc}</p>
                </div>
                <div className="shrink-0">
                  <span className="bit-stamp text-[10px] text-[#00E5A0] border-[#00E5A0]">{role.type}</span>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-6">
            <Link
              href="/contact"
              className="inline-flex items-center gap-2 px-6 py-3 bg-[#7B61FF] text-white font-display font-black text-sm uppercase tracking-wider rounded hover:bg-[#7B61FF]/80 transition-all"
            >
              Apply Now →
            </Link>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
