# BRAINCELLS IN THEORY (BiT) — Design Brainstorm

## Three Stylistic Approaches

### Option A: "Brutalist Notebook"
A raw, handwritten-meets-digital aesthetic. Torn paper textures, highlighter smears, ink stamps, and ruled-line backgrounds. Feels like a student's chaotic binder exploded into a website.
**Probability:** 0.07

### Option B: "Neon Dread"
Dark academic horror-comedy. Deep charcoal backgrounds, acid-green and electric-yellow accents, glitchy type effects, and dramatic drop shadows. Feels like studying at 3am with existential dread.
**Probability:** 0.04

### Option C: "Chaotic Textbook Riot" ← CHOSEN
A maximalist, sarcastic take on educational design. Bold serif headlines clash with monospace code-like labels. Highlighter-yellow, blood-orange, and chalk-white on near-black. Feels like a textbook that got tired of being boring and started roasting students.
**Probability:** 0.09

---

## CHOSEN: "Chaotic Textbook Riot"

### Design Movement
Post-ironic editorial brutalism — the aesthetic language of zines, protest posters, and academic journals that have lost their minds.

### Core Principles
1. **Deliberate Chaos with Structure** — Asymmetric layouts, clashing type sizes, and intentional "mistakes" that are actually precise design decisions.
2. **Sarcasm as Visual Language** — Strikethroughs, parenthetical asides, footnote aesthetics, and red-pen corrections baked into the UI.
3. **High Contrast, Low Mercy** — Near-black backgrounds with screaming accent colors. No soft pastels. No gentle gradients.
4. **Motion as Punchline** — Animations that feel like they're mocking you: wobbles, dramatic reveals, over-the-top transitions.

### Color Philosophy
Not just a palette — a mood. The colors should feel like a highlighter exploded on a chalkboard.
- **Background:** `#0D0D0D` (near-black, not pure — has warmth)
- **Primary Text:** `#F5F0E8` (aged paper white — not sterile)
- **Signature Brand Color:** `#FFD600` (screaming highlighter yellow — unmistakably BiT)
- **Accent 1:** `#FF4D1C` (blood orange — panic, urgency, sarcasm)
- **Accent 2:** `#00E5A0` (toxic mint — "you're doing great, buddy")
- **Accent 3:** `#7B61FF` (bruised purple — for math, suffering)
- **Muted:** `#2A2A2A` (card backgrounds)

### Layout Paradigm
Asymmetric editorial grid. Content blocks are deliberately misaligned — some flush left, some indented, some overlapping. Headers break the grid. Sections use full-bleed color blocks with offset text. No centered hero worship.

### Signature Elements
1. **Red-pen corrections** — Strikethrough text with handwritten-style corrections in red/orange
2. **Footnote aesthetics** — Small superscript numbers leading to sarcastic footnotes
3. **Rubber stamp labels** — Bold, slightly rotated category tags that look like "URGENT", "EXAM SOON", "COPE"

### Interaction Philosophy
Every interaction should feel slightly dramatic. Hover states are exaggerated. Buttons resist before clicking. The site has opinions about you.

### Animation
- **Scroll reveals:** Text slides in from the left like it's being written in real-time
- **Hover:** Cards tilt 2-3° and cast dramatic shadows
- **Page transitions:** Wipe effects, like turning a page
- **Panic Mode:** Everything shakes, turns red, countdown timer pulses
- **Floating objects:** Pencils, equations, coffee cups drift in the hero
- **Stagger:** 40-60ms between list items
- **Duration:** 200-350ms for UI, 600-900ms for scroll reveals

### Typography System
- **Display/Headlines:** `Space Grotesk` — bold, slightly quirky, not Inter
- **Body:** `DM Serif Display` for pull quotes, `DM Sans` for body text
- **Monospace/Labels:** `JetBrains Mono` — for code-like labels, stats, counters
- **Hierarchy:** H1 at 5-8rem, H2 at 2.5-4rem, body at 1rem/1.125rem
- **Technique:** Mix weights aggressively — 900 headlines next to 300 captions

### Brand Essence
BiT is the study platform for students who know they're cooked but show up anyway. For the chronically overwhelmed. Different because it's honest about how bad studying feels.
**Personality:** Sarcastic. Relentless. Secretly supportive.

### Brand Voice
Headlines sound like a friend who's also failing but somehow knows everything.
- "You're not behind. You're just... very ahead of being behind."
- "Math didn't ruin your life. You let it."
CTAs are commands, not suggestions: "Start suffering smarter." "Enter if you dare."
Ban: "Welcome!", "Get started today", "Unlock your potential"

### Wordmark & Logo
A stylized brain icon with a lightning bolt through it — rendered as a bold geometric mark. The "BiT" wordmark uses Space Grotesk 900 with the "i" replaced by a lightning bolt glyph. Logo on transparent background.

### Signature Brand Color
`#FFD600` — Highlighter Yellow. Unmistakably BiT.

---

## Style Decisions
- All section dividers use the rubber-stamp / torn-edge aesthetic, never smooth waves
- Sarcastic microcopy appears in every empty state, loading state, and error message
- The mascot is a brain with googly eyes named "Brainy" — appears in easter eggs and panic mode
- Dark theme is default and permanent — no light mode (students study at night)
- Subject colors: Math=purple, Science=mint, History=orange, English=yellow

## Style Decisions

The following rules were adopted after the first style review pass:

1. **Every major page must include at least one obvious "textbook vandalism" device**: red-pen correction, sarcastic footnote, torn-edge divider, highlighter smear, or marginal annotation. These are implemented via the `TextbookVandalism.tsx` component library.

2. **Layout should never resolve into a fully polite SaaS grid for an entire section**; each page needs at least one asymmetric editorial break with offset, overlap, or intentionally disrupted alignment. `EditorialBreak` components serve this role between sections.

3. **The BiT wordmark must use Space Grotesk 900 with a lightning-bolt "i,"** and the highlighter yellow `#FFD600` remains the primary brand ownership color for logo emphasis, primary actions, and key numerals.

4. **Stamp components** (`<Stamp>`) appear on page heroes at slight rotations to reinforce the rubber-stamp brand grammar.

5. **`MarginNote` components** appear alongside sarcastic pull-quotes to simulate teacher annotations in the margins.

6. **`TeacherNote` components** appear in feature sections to add red-pen "see me after class" energy.

7. **`Footnote` components** appear at the bottom of feature sections with sarcastic academic disclaimers.
